"""
experiments/run_clean_baseline.py — Clean-run false-positive-rate check (§6.3).

Runs the invariant-enforcing pipeline with NO defect injected, across:
  - 3 models × 2 datasets × 5 seeds = 30 total runs

For each run, records whether any invariant fired incorrectly and the ⊥ rate.

Expected result: FPR = 0.0% (no invariant fires on a clean run).

Writes:
  - results/clean_baseline_fpr.csv (30 rows)

Usage:
    python experiments/run_clean_baseline.py
    python experiments/run_clean_baseline.py --dry-run
"""
from __future__ import annotations

import argparse
import csv
import logging
import random
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(exist_ok=True)
FPR_PATH = RESULTS_DIR / "clean_baseline_fpr.csv"

FPR_FIELDS = [
    "model", "dataset", "seed",
    "conservation_fired", "closed_vocab_fired",
    "bot_rate", "fpr_contribution",
]

CONFIG_PATH = Path(__file__).parent / "experiment_config.yaml"


def load_config():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


def run_clean_cell_dry(model_name, dataset_name, seed):
    """Dry-run: return clean results (FPR=0)."""
    rng = random.Random(seed + hash(model_name + dataset_name) % 1000)
    bot_rate = rng.uniform(0.001, 0.005)
    return {
        "model": model_name,
        "dataset": dataset_name,
        "seed": seed,
        "conservation_fired": False,
        "closed_vocab_fired": False,
        "bot_rate": round(bot_rate * 100, 3),
        "fpr_contribution": 0.0,
    }


def run_clean_cell(model, tokenizer, model_name, dataset_name, seed, config):
    """Live run: invariant-enforcing pipeline with no defect."""
    from data.loaders import get_dataset  # type: ignore
    from data.taxonomies import get_taxonomy  # type: ignore
    from data.normalizers import norm_strip_lower  # type: ignore
    from invariants.wrapper import build_lookup_table, invariant_enforcing_eval  # type: ignore
    from invariants.core import (  # type: ignore
        ConservationViolation, ClosedVocabularyViolation,
        assert_conservation, assert_closed_vocabulary,
    )

    random.seed(seed)

    test_set = get_dataset(dataset_name)
    taxonomy = get_taxonomy(dataset_name)
    normalizer = norm_strip_lower
    lookup_table = build_lookup_table(taxonomy, normalizer)

    dcfg = config.get("generation", {})
    result = invariant_enforcing_eval(
        model=model, tokenizer=tokenizer,
        test_set=test_set,
        taxonomy=taxonomy,
        normalizer=normalizer,
        lookup_table=lookup_table,
        batch_size=dcfg.get("batch_size", 8),
        max_new_tokens=dcfg.get("max_new_tokens", 16),
    )

    conservation_fired = False
    closed_vocab_fired = False

    # These should NOT fire on a clean run
    try:
        assert_conservation(result["scored_predictions"], len(test_set))
    except ConservationViolation:
        conservation_fired = True
        logger.warning(f"Conservation fired on clean run! {model_name}/{dataset_name}/seed={seed}")

    try:
        assert_closed_vocabulary(taxonomy, normalizer, lookup_table)
    except ClosedVocabularyViolation:
        closed_vocab_fired = True
        logger.warning(f"Closed-Vocabulary fired on clean run! {model_name}/{dataset_name}/seed={seed}")

    fpr_contribution = 1.0 if (conservation_fired or closed_vocab_fired) else 0.0

    return {
        "model": model_name,
        "dataset": dataset_name,
        "seed": seed,
        "conservation_fired": conservation_fired,
        "closed_vocab_fired": closed_vocab_fired,
        "bot_rate": round(result["bot_rate"] * 100, 3),
        "fpr_contribution": fpr_contribution,
    }


def main(dry_run=False):
    config = load_config()
    model_names = [m["name"] for m in config["models"]]
    dataset_names = list(config["datasets"].keys())
    seeds = config["seeds"]["clean_baseline"]

    all_rows = []

    if dry_run:
        logger.info("DRY RUN MODE")
        for model_name in model_names:
            for dataset_name in dataset_names:
                for seed in seeds:
                    row = run_clean_cell_dry(model_name, dataset_name, seed)
                    all_rows.append(row)
    else:
        from models.loader import load_model  # type: ignore

        for model_name in model_names:
            model, tokenizer = load_model(model_name)
            for dataset_name in dataset_names:
                for seed in seeds:
                    logger.info(f"Clean run: {model_name}/{dataset_name}/seed={seed}")
                    row = run_clean_cell(model, tokenizer, model_name, dataset_name, seed, config)
                    all_rows.append(row)
                    logger.info(f"  {row}")
            del model, tokenizer
            try:
                import torch; torch.cuda.empty_cache()
            except Exception:
                pass

    assert len(all_rows) == 30, f"Expected 30 rows, got {len(all_rows)}"

    fpr = sum(r["fpr_contribution"] for r in all_rows) / len(all_rows)
    logger.info(f"Aggregate FPR = {fpr:.4f} (expected 0.0)")

    with open(FPR_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FPR_FIELDS)
        writer.writeheader()
        writer.writerows(all_rows)

    logger.info(f"FPR results written to {FPR_PATH}")

    if fpr != 0.0:
        logger.error(
            f"FPR is non-zero ({fpr:.4f}). "
            "Check the invariant implementation or normalizer choice."
        )
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    main(dry_run=args.dry_run)

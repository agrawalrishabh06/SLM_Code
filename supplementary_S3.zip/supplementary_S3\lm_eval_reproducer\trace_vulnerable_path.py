"""
lm_eval_reproducer/trace_vulnerable_path.py

Standalone script that OPENS the vulnerable file in lm-evaluation-harness
and prints the exact mean function that filters None. For reviewers who
don't want to run the full eval but want to verify the claim.

Usage:
    # After pip install lm-eval==0.4.3:
    python lm_eval_reproducer/trace_vulnerable_path.py

Expected output (v0.4.3):
    VULNERABLE PATH: /path/to/lm_eval/api/metrics.py:<line>
    def mean(arr):
        return sum(arr) / len(arr)
    ...or...
    return mean([x for x in arr if x is not None])
"""
import sys

try:
    import inspect
    import importlib

    module = importlib.import_module("lm_eval.api.metrics")
    src_path = inspect.getsourcefile(module)
    src_lines = inspect.getsource(module).split("\n")

    # Find the `mean` function or the None-filtering aggregation
    found = False
    for i, line in enumerate(src_lines, start=1):
        if line.startswith("def mean(") or "is not None" in line:
            print(f"VULNERABLE PATH: {src_path}:{i}")
            # Print the next 8 lines for context
            snippet = src_lines[i - 1: i + 7]
            print("\n".join(snippet))
            print()
            found = True
            if line.startswith("def mean("):
                break  # Only show the first match for the mean function

    if not found:
        print(
            "Could not find the vulnerable path. "
            "Make sure lm-eval==0.4.3 is installed."
        )
        sys.exit(1)

except ImportError:
    print(
        "lm_eval is not installed. Install with:\n"
        "  pip install lm-eval==0.4.3\n"
        "or follow setup.sh."
    )
    sys.exit(1)

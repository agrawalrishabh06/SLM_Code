"""
experiments/run_banking77_incident.py — Banking77 incident reproducer (§6.2).

IMPORTANT HONEST DOCUMENTATION NOTE:
This reproducer uses the public Llama-3-8B-Instruct BASE MODEL instead of our
internal fine-tuned checkpoint. The confusion-matrix collapse pattern should
hold qualitatively, but the exact numbers (88.3% / 85.5% / 12.9% ⊥ / ~90%
collapse) may differ. The paper's numbers come from an internal fine-tuned
model which we cannot release.

What this reproducer demonstrates:
  1. Evaluating with D2 (.upper().strip() normalizer) → inflated accuracy
  2. Evaluating with invariant-enforcing pipeline → corrected accuracy
  3. Confusion matrix showing collapse onto dominant wrong class

Writes:
  - results/banking77_incident.csv
  - results/banking77_confusion_matrix.png

Usage:
    python experiments/run_banking77_incident.py
    python experiments/run_banking77_incident.py --dry-run
"""
from __future__ import annotations

import argparse
import csv
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(exist_ok=True)

INCIDENT_PATH = RESULTS_DIR / "banking77_incident.csv"
CONFUSION_PATH = RESULTS_DIR / "banking77_confusion_matrix.png"

INCIDENT_FIELDS = [
    "defective_acc", "true_acc", "bot_rate",
    "off_diagonal_fraction_on_dominant_class", "dominant_class",
]


def run_incident_dry():
    """Dry-run with paper-claimed numbers."""
    return {
        "defective_acc": 88.3,
        "true_acc": 85.5,
        "bot_rate": 12.9,
        "off_diagonal_fraction_on_dominant_class": 89.7,
        "dominant_class": "activate_my_card",
    }


def run_incident_live():
    """Live run using public Llama-3-8B-Instruct base model."""
    from models.loader import load_model  # type: ignore
    from models.generate import greedy_generate  # type: ignore
    from models.prompts import build_prompt  # type: ignore
    from data.loaders import load_banking77  # type: ignore
    from data.taxonomies import BANKING77_LABELS  # type: ignore
    from data.normalizers import norm_banking77_bug, norm_strip_lower  # type: ignore
    from invariants.wrapper import build_lookup_table, invariant_enforcing_eval  # type: ignore
    from invariants.core import BOT  # type: ignore

    model, tokenizer = load_model("llama-3-8b-instruct", quantize=True)
    test_set = load_banking77()
    taxonomy = BANKING77_LABELS

    prompts = [build_prompt("banking77", ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    # --- Defective run (D2 with .upper().strip() normalizer) ---
    logger.info("Running defective evaluation (D2: .upper().strip() normalizer)...")
    raw_outputs = greedy_generate(model, tokenizer, prompts)

    # Build table with UPPERCASE keys (what the defective harness used)
    defective_table = {label.upper(): label for label in taxonomy}
    buggy_normalizer = norm_banking77_bug  # .upper().strip()

    matched_preds = []
    matched_golds = []
    n_dropped = 0
    for raw_out, gold in zip(raw_outputs, gold_labels):
        norm_out = buggy_normalizer(raw_out.strip())
        if norm_out in defective_table:
            matched_preds.append(defective_table[norm_out])
            matched_golds.append(gold)
        else:
            n_dropped += 1

    n_matched = len(matched_preds)
    n_correct_def = sum(1 for p, g in zip(matched_preds, matched_golds) if p == g)
    defective_acc = (n_correct_def / n_matched * 100) if n_matched > 0 else 0.0

    # --- Invariant-enforcing run ---
    logger.info("Running invariant-enforcing evaluation...")
    clean_normalizer = norm_strip_lower
    lookup_table = build_lookup_table(taxonomy, clean_normalizer)
    inv_result = invariant_enforcing_eval(
        model=model, tokenizer=tokenizer,
        test_set=test_set,
        taxonomy=taxonomy,
        normalizer=clean_normalizer,
        lookup_table=lookup_table,
    )
    true_acc = inv_result["accuracy_with_bot_as_error"] * 100
    bot_rate = inv_result["bot_rate"] * 100

    # --- Confusion matrix analysis ---
    scored = inv_result["scored_predictions"]
    wrong_preds = [p for p, g in zip(scored, gold_labels) if p is not BOT and p != g]
    if wrong_preds:
        from collections import Counter
        counts = Counter(wrong_preds)
        dominant_class, dominant_count = counts.most_common(1)[0]
        off_diag_fraction = dominant_count / len(wrong_preds) * 100
    else:
        dominant_class = "N/A"
        off_diag_fraction = 0.0

    logger.info(
        f"Defective acc: {defective_acc:.1f}% | True acc: {true_acc:.1f}% | "
        f"BOT rate: {bot_rate:.1f}% | Off-diag dominant: {dominant_class} ({off_diag_fraction:.1f}%)"
    )

    # --- Confusion matrix visualization ---
    try:
        import matplotlib.pyplot as plt  # type: ignore
        import seaborn as sns  # type: ignore
        import numpy as np  # type: ignore

        # Build a 10×10 confusion sub-matrix (top 10 labels by frequency)
        from collections import Counter
        top_labels = [l for l, _ in Counter(gold_labels).most_common(10)]

        # Build confusion matrix for top labels
        n = len(top_labels)
        label_idx = {l: i for i, l in enumerate(top_labels)}
        cm = np.zeros((n, n), dtype=int)
        for p, g in zip(scored, gold_labels):
            if g in label_idx:
                p_str = p if p is not BOT else "__BOT__"
                p_idx = label_idx.get(p_str, -1)
                g_idx = label_idx[g]
                if p_idx >= 0:
                    cm[g_idx][p_idx] += 1

        fig, ax = plt.subplots(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt="d", xticklabels=top_labels, yticklabels=top_labels, ax=ax)
        ax.set_title("Banking77 Confusion Matrix (Defective Run)\nNote: Uses public base model; paper used fine-tuned checkpoint")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Gold")
        plt.tight_layout()
        plt.savefig(CONFUSION_PATH, dpi=150)
        plt.close()
        logger.info(f"Confusion matrix saved to {CONFUSION_PATH}")
    except ImportError:
        logger.warning("matplotlib/seaborn not available; skipping confusion matrix plot.")

    del model, tokenizer
    try:
        import torch; torch.cuda.empty_cache()
    except Exception:
        pass

    return {
        "defective_acc": round(defective_acc, 1),
        "true_acc": round(true_acc, 1),
        "bot_rate": round(bot_rate, 1),
        "off_diagonal_fraction_on_dominant_class": round(off_diag_fraction, 1),
        "dominant_class": dominant_class,
    }


def main(dry_run=False):
    if dry_run:
        logger.info("DRY RUN MODE")
        result = run_incident_dry()
    else:
        result = run_incident_live()

    with open(INCIDENT_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=INCIDENT_FIELDS)
        writer.writeheader()
        writer.writerow(result)

    logger.info(f"Banking77 incident results written to {INCIDENT_PATH}")
    logger.info(f"Results: {result}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    main(dry_run=args.dry_run)

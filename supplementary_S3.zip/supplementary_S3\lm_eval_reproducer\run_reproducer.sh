#!/bin/bash
set -euo pipefail

# run_reproducer.sh — Reproduce the silent-skip instance from Section 6.4.
#
# Expected output:
#   Reported accuracy: ~89.47%
#   True accuracy:     ~82.76%
#   Unparseable (K):   ~231 out of 3,080
#
# Prerequisites:
#   git clone https://github.com/EleutherAI/lm-evaluation-harness
#   cd lm-evaluation-harness && git checkout v0.4.3 && pip install -e .
#   cp -r $(dirname "$0")/banking77_generate lm_eval/tasks/

MODEL="mistralai/Mistral-7B-Instruct-v0.3"
OUTPUT_DIR="$(dirname "$0")/output"
mkdir -p "$OUTPUT_DIR"

lm_eval \
  --model hf \
  --model_args "pretrained=${MODEL},load_in_4bit=True" \
  --tasks banking77_generate \
  --num_fewshot 0 \
  --batch_size 8 \
  --output_path "$OUTPUT_DIR" \
  --log_samples 2>&1 | tee "$OUTPUT_DIR/run.log"

echo "Done. Check $OUTPUT_DIR/run.log for the K count and reported accuracy."
echo ""
echo "To count the number of None returns (K):"
echo "  grep -c 'acc.*None\|None.*acc' $OUTPUT_DIR/run.log || echo 'check the samples JSON'"

"""
defects/d5_permutation.py — D5: Prompt-order permutation.

NOT part of the main injection study. Used for the NEGATIVE RESULT showing
that the three invariants (Conservation, Closed-Vocabulary, Unmatched-Output)
do NOT detect order-bias effects.

D5 permutes the candidate label list in the prompt. This can shift accuracy
by several points due to positional bias in LLMs, but:
  - Conservation still holds (no rows dropped)
  - Closed-Vocabulary still holds (no key loss)
  - Unmatched-Output does not increase (the model still outputs valid labels)

This is the paper's honesty move (§6.5): explicit evidence of what the
invariants miss.
"""
from __future__ import annotations

import random
from typing import Any, Callable, Dict, List


def apply_d5(taxonomy: List[str], seed: int) -> List[str]:
    """D5: Prompt-order permutation.

    Returns a permuted copy of the taxonomy list. When used in the prompt as
    'Choose from: A, B, C, ...', the ordering can bias the model's output
    without changing anything structural about scoring.

    Args:
        taxonomy: The canonical label list.
        seed: Random seed for reproducible permutation.

    Returns:
        A permuted copy of taxonomy (same elements, different order).
    """
    rng = random.Random(seed)
    permuted = list(taxonomy)
    rng.shuffle(permuted)
    return permuted


def build_prompt_with_ordered_list(
    dataset: str,
    query: str,
    label_order: List[str],
) -> str:
    """Build a prompt that includes an explicit ordered list of candidate labels.

    This is used in the D5 experiment to test whether label order in the prompt
    affects the model's output distribution.

    Args:
        dataset: One of {"banking77", "clinc150"}.
        query: The query string.
        label_order: The permuted label list to include in the prompt.

    Returns:
        A formatted prompt string with the candidate list embedded.
    """
    labels_str = ", ".join(label_order)

    if dataset == "banking77":
        return (
            f"You are a banking customer support assistant. "
            f"Classify the following customer query into one of these categories:\n"
            f"{labels_str}\n\n"
            f"Query: {query}\n\n"
            f"Reply with only the intent label. Intent:"
        )
    elif dataset in ("clinc150", "clinc150_inscope"):
        return (
            f"You are an intent classifier. "
            f"Classify the following query into one of these categories:\n"
            f"{labels_str}\n\n"
            f"Query: {query}\n\n"
            f"Reply with only the intent label. Intent:"
        )
    else:
        raise ValueError(f"Unknown dataset '{dataset}'")


def defective_pipeline_d5(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str],
    lookup_table: Dict[str, str],
    permutation_seed: int = 0,
    batch_size: int = 8,
    max_new_tokens: int = 16,
) -> Dict[str, Any]:
    """Run evaluation with D5 (permuted label order in prompts).

    All three invariants should pass. Accuracy may differ from baseline.
    This demonstrates what the invariants miss: order-bias effects.

    Returns a dict with:
        accuracy: float — accuracy with BOT as wrong
        conservation_fired: bool — always False
        closed_vocab_fired: bool — always False
        bot_rate: float — typically low
        permutation_seed: int
    """
    from models.generate import greedy_generate  # type: ignore
    from invariants.core import (  # type: ignore
        BOT, assert_conservation, assert_closed_vocabulary,
        route_unmatched_to_bot, ClosedVocabularyViolation, ConservationViolation
    )
    from invariants.metrics import accuracy as compute_accuracy  # type: ignore

    permuted_labels = apply_d5(taxonomy, permutation_seed)

    prompts = [
        build_prompt_with_ordered_list(
            "banking77" if len(taxonomy) == 77 else "clinc150",
            ex["text"],
            permuted_labels,
        )
        for ex in test_set
    ]
    gold_labels = [ex["label_text"] for ex in test_set]

    raw_outputs = greedy_generate(model, tokenizer, prompts, max_new_tokens, batch_size)

    scored_predictions = []
    for raw_out in raw_outputs:
        norm_out = normalizer(raw_out.strip())
        scored_predictions.append(route_unmatched_to_bot(norm_out, lookup_table))

    conservation_fired = False
    closed_vocab_fired = False

    try:
        assert_conservation(scored_predictions, len(test_set))
    except ConservationViolation:
        conservation_fired = True

    try:
        assert_closed_vocabulary(taxonomy, normalizer, lookup_table)
    except ClosedVocabularyViolation:
        closed_vocab_fired = True

    acc = compute_accuracy(scored_predictions, gold_labels)
    n_unmatched = sum(1 for p in scored_predictions if p is BOT)

    return {
        "accuracy": acc,
        "conservation_fired": conservation_fired,
        "closed_vocab_fired": closed_vocab_fired,
        "bot_rate": n_unmatched / len(test_set) if test_set else 0.0,
        "permutation_seed": permutation_seed,
    }

"""
defects/d1_silent_skip.py — D1: Silent skip on lookup mismatch.

The Dell-incident defect pattern. A buggy harness drops unmatched predictions
from the denominator instead of counting them as wrong. The denominator
shrinks silently, inflating accuracy.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List


def apply_d1(
    scored_predictions: List[Any],
    unmatched_count: int,
) -> List[Any]:
    """D1: Silent skip.

    Simulates a defective harness that drops unmatched predictions from
    the denominator. Returns a list with the last `unmatched_count` entries
    removed (simulating the harness dropping None/unmatched rows).

    In a real defective harness, rows are dropped at lookup time; here we
    model it as removing the last N entries for testability.

    Args:
        scored_predictions: The full list of predictions (before dropping).
        unmatched_count: Number of unmatched entries to drop.

    Returns:
        List of length len(scored_predictions) - unmatched_count.
    """
    if unmatched_count < 0 or unmatched_count > len(scored_predictions):
        raise ValueError(
            f"unmatched_count={unmatched_count} is out of range "
            f"[0, {len(scored_predictions)}]"
        )
    if unmatched_count == 0:
        return list(scored_predictions)
    return list(scored_predictions[:-unmatched_count])


def defective_pipeline_d1(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str],
    lookup_table: Dict[str, str],
    batch_size: int = 8,
    max_new_tokens: int = 16,
    dataset_name: str = "banking77",
) -> Dict[str, Any]:
    """Run a full evaluation using the D1-defective harness pattern.

    The defective harness:
      - Does NOT enforce the Conservation invariant.
      - Drops any prediction that does not match the lookup table.
      - Computes accuracy over the reduced denominator (inflated result).

    Returns a dict with:
        defective_acc: float — accuracy over matched rows only
        n_total: int — original test set size
        n_matched: int — rows that matched
        n_dropped: int — rows silently dropped
    """
    from models.generate import greedy_generate  # type: ignore
    from models.prompts import build_prompt  # type: ignore

    prompts = [build_prompt(dataset_name, ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    raw_outputs = greedy_generate(model, tokenizer, prompts, max_new_tokens, batch_size)

    matched_preds = []
    matched_golds = []
    n_dropped = 0

    for raw_out, gold in zip(raw_outputs, gold_labels):
        norm_out = normalizer(raw_out.strip())
        if norm_out in lookup_table:
            matched_preds.append(lookup_table[norm_out])
            matched_golds.append(gold)
        else:
            n_dropped += 1  # Silent skip — not counted

    n_matched = len(matched_preds)
    n_correct = sum(1 for p, g in zip(matched_preds, matched_golds) if p == g)
    defective_acc = n_correct / n_matched if n_matched > 0 else 0.0

    return {
        "defective_acc": defective_acc,
        "n_total": len(test_set),
        "n_matched": n_matched,
        "n_dropped": n_dropped,
    }

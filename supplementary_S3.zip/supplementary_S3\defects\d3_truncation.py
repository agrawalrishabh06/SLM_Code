"""
defects/d3_truncation.py — D3: Decode-length truncation.

Generation budget is set too short to emit the full label string for
long-labeled classes. Labels get cut mid-word and fail to match any key
in the lookup table.

For Banking77, the longest label "wrong_exchange_rate_for_cash_withdrawal"
tokenizes to ~12-18 tokens depending on the tokenizer. A budget of 5 tokens
causes many long-label classes to truncate.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List


def apply_d3(
    model,
    tokenizer,
    prompts: List[str],
    truncation_tokens: int = 5,
) -> List[str]:
    """D3: Decode-length truncation.

    Generates with a very short max_new_tokens so long-labeled classes
    get cut mid-word, producing outputs that don't match any lookup key.

    Args:
        model: A transformers PreTrainedModel in eval mode.
        tokenizer: The matching tokenizer.
        prompts: List of prompt strings.
        truncation_tokens: Maximum new tokens to generate (much smaller
            than the longest label's token count).

    Returns:
        List of truncated output strings.
    """
    from models.generate import greedy_generate  # type: ignore
    return greedy_generate(model, tokenizer, prompts, max_new_tokens=truncation_tokens)


def defective_pipeline_d3(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str],
    lookup_table: Dict[str, str],
    truncation_tokens: int = 5,
    dataset_name: str = "banking77",
) -> Dict[str, Any]:
    """Run a full evaluation using the D3-defective harness pattern.

    Short generation budget causes many outputs to fail lookup, which
    the defective harness silently drops.
    """
    from models.prompts import build_prompt  # type: ignore

    prompts = [build_prompt(dataset_name, ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    raw_outputs = apply_d3(model, tokenizer, prompts, truncation_tokens)

    matched_preds = []
    matched_golds = []
    n_dropped = 0

    for raw_out, gold in zip(raw_outputs, gold_labels):
        norm_out = normalizer(raw_out.strip())
        if norm_out in lookup_table:
            matched_preds.append(lookup_table[norm_out])
            matched_golds.append(gold)
        else:
            n_dropped += 1

    n_matched = len(matched_preds)
    n_correct = sum(1 for p, g in zip(matched_preds, matched_golds) if p == g)
    defective_acc = n_correct / n_matched if n_matched > 0 else 0.0

    return {
        "defective_acc": defective_acc,
        "n_total": len(test_set),
        "n_matched": n_matched,
        "n_dropped": n_dropped,
        "truncation_tokens": truncation_tokens,
    }

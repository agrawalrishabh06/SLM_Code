"""
defects/d4_vocab_drift.py — D4: Label-vocabulary drift.

The lookup table is built from a renamed taxonomy. The model outputs original
label names (what it was trained/prompted on), but those names no longer
match the renamed keys — causing silent lookup failures.
"""
from __future__ import annotations

import random
from typing import Any, Callable, Dict, List


# Rename map for Banking77 — a realistic set of 5 label renames
_BANKING77_RENAMES = {
    "activate_my_card": "card_activation",
    "lost_or_stolen_card": "report_lost_card",
    "balance_not_updated_after_bank_transfer": "missing_transfer_balance",
    "change_pin": "update_pin",
    "transfer_not_received_by_recipient": "missing_recipient_transfer",
}


def apply_d4(
    taxonomy: List[str],
    n_renames: int = 5,
    rename_map: Dict[str, str] = None,
    seed: int = 42,
) -> Dict[str, str]:
    """D4: Vocabulary drift.

    Returns a lookup table where `n_renames` labels have been renamed.
    The gold labels in the test set remain the original names, so the
    model's correct outputs no longer match the drifted table.

    Args:
        taxonomy: The original canonical label list.
        n_renames: Number of labels to rename.
        rename_map: Optional explicit rename mapping (label → new_name).
            If None, uses the Banking77 defaults (or random renames for
            other taxonomies).
        seed: Random seed for reproducible random renames.

    Returns:
        Dict mapping new_name → original_label (the drifted lookup table).
        The table has the same number of entries as the taxonomy.
    """
    rng = random.Random(seed)

    if rename_map is None:
        # Use Banking77 renames if applicable, else random renames
        applicable_renames = {
            k: v for k, v in _BANKING77_RENAMES.items() if k in taxonomy
        }
        if len(applicable_renames) >= n_renames:
            rename_map = dict(list(applicable_renames.items())[:n_renames])
        else:
            # Generate random renames for other taxonomies
            labels_to_rename = rng.sample(taxonomy, min(n_renames, len(taxonomy)))
            rename_map = {label: f"renamed_{label}" for label in labels_to_rename}

    # Build the drifted lookup table
    drifted_table: Dict[str, str] = {}
    for label in taxonomy:
        if label in rename_map:
            new_key = rename_map[label]
        else:
            new_key = label
        drifted_table[new_key] = label

    assert len(drifted_table) == len(taxonomy), (
        "Drifted table length mismatch — check for key collisions in rename_map"
    )
    return drifted_table


def defective_pipeline_d4(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str],
    n_renames: int = 5,
    batch_size: int = 8,
    max_new_tokens: int = 16,
    dataset_name: str = "banking77",
) -> Dict[str, Any]:
    """Run a full evaluation using the D4-defective harness pattern.

    The lookup table uses renamed labels; model outputs the original
    names → mismatches.
    """
    from models.generate import greedy_generate  # type: ignore
    from models.prompts import build_prompt  # type: ignore

    drifted_table = apply_d4(taxonomy, n_renames=n_renames)

    prompts = [build_prompt(dataset_name, ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    raw_outputs = greedy_generate(model, tokenizer, prompts, max_new_tokens, batch_size)

    matched_preds = []
    matched_golds = []
    n_dropped = 0

    for raw_out, gold in zip(raw_outputs, gold_labels):
        norm_out = normalizer(raw_out.strip())
        if norm_out in drifted_table:
            matched_preds.append(drifted_table[norm_out])
            matched_golds.append(gold)
        else:
            n_dropped += 1

    n_matched = len(matched_preds)
    n_correct = sum(1 for p, g in zip(matched_preds, matched_golds) if p == g)
    defective_acc = n_correct / n_matched if n_matched > 0 else 0.0

    return {
        "defective_acc": defective_acc,
        "n_total": len(test_set),
        "n_matched": n_matched,
        "n_dropped": n_dropped,
        "n_renames": n_renames,
    }

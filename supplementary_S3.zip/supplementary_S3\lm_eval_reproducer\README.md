# lm-evaluation-harness Reproducer (§6.4)

This directory contains the files needed to reproduce the silent-skip instance
from Section 6.4 of the paper using `lm-evaluation-harness` v0.4.3.

## What this demonstrates

A custom `banking77_generate` task that returns `{"acc": None}` when the model
output doesn't match the expected regex. The `lm-evaluation-harness` mean
aggregator at `lm_eval/api/metrics.py` filters `None` values before averaging,
so these rows silently exit the denominator — inflating reported accuracy.

**Expected output:**
- Reported accuracy: ~89.47%
- True accuracy (with None counted as wrong): ~82.76%
- Unparseable generations (K): ~231 out of 3,080

## Setup

```bash
# Install lm-evaluation-harness v0.4.3
git clone https://github.com/EleutherAI/lm-evaluation-harness
cd lm-evaluation-harness
git checkout v0.4.3
pip install -e .

# Copy the custom task
cp -r ../banking77_generate lm_eval/tasks/
```

## Run

```bash
bash run_reproducer.sh
```

## Files

- `banking77_generate/banking77_generate.yaml` — The task config (shown in Appendix C)
- `banking77_generate/utils.py` — The regex extractor that returns `None` on parse failure
- `run_reproducer.sh` — The exact shell command from the paper
- `trace_vulnerable_path.py` — Prints the vulnerable code path without running inference

# Supplementary Code Bundle S3

## "Silent Failures in Large Language Model Evaluation: Correctness Invariants for Trustworthy Classification Benchmarks"

> ACL ARR — Anonymous Submission

---

## Table of Contents

1. [Overview](#1-overview)
2. [Directory Structure](#2-directory-structure)
3. [All Files — Detailed Index](#3-all-files--detailed-index)
4. [Experiments](#4-experiments)
5. [Results Summary](#5-results-summary)
6. [Reproduction Guide](#6-reproduction-guide)
7. [Hardware Requirements](#7-hardware-requirements)
8. [Dependencies](#8-dependencies)
9. [Paper → Code Mapping](#9-paper--code-mapping)
10. [What Is Not Included](#10-what-is-not-included)
11. [Citation](#11-citation)

---

## 1. Overview

This bundle provides the complete, self-contained reproducibility code for the paper. The paper identifies **silent failure modes** in LLM classification evaluation harnesses — bugs that inflate or distort reported accuracy without raising any error — and proposes three **correctness invariants** that detect them automatically.

### Core contributions reproduced here

| Contribution | What it is | Where in this bundle |
|---|---|---|
| **Three invariants** | Conservation, Closed-Vocabulary, Unmatched-Output Accounting | `invariants/` |
| **Algorithm 1** | Invariant-enforcing evaluation wrapper | `invariants/wrapper.py` |
| **Equation 2** | Accuracy inflation formula Δ = r(a_k − a_d) | `invariants/metrics.py`, `analysis/compute_inflation.py` |
| **Five defect classes** | D1–D5 failure modes with inject-able pipelines | `defects/` |
| **24-cell injection study** | 3 models × 2 datasets × 4 defects | `experiments/run_injection_matrix.py` |
| **Real incident reproducers** | Dell production triage (§6.1), Banking77 (§6.2), lm-eval (§6.4) | `experiments/`, `lm_eval_reproducer/` |
| **D5 negative result** | Prompt-order permutation does NOT trigger invariants | `experiments/run_d5_negative.py` |

---

## 2. Directory Structure

```
supplementary_S3/
│
├── README.md                          ← This file
├── requirements.txt                   ← Pinned Python dependencies
├── setup.sh                           ← One-shot environment + lm-eval setup
├── LICENSE                            ← Apache 2.0
├── CITATION.bib                       ← BibTeX entry for this paper
│
├── invariants/                        ← Core paper contribution (§4)
│   ├── __init__.py
│   ├── core.py                        ← Three invariants as pure functions
│   ├── wrapper.py                     ← Algorithm 1 implementation
│   ├── metrics.py                     ← Accuracy, macro-F1, inflation Δ
│   └── test_invariants.py             ← 20 pytest unit tests
│
├── data/                              ← Dataset loading and vocabularies
│   ├── __init__.py
│   ├── loaders.py                     ← HuggingFace loaders with assertion gates
│   ├── taxonomies.py                  ← Canonical label lists (77 / 150 / 15)
│   ├── normalizers.py                 ← 5 string normalizers (incl. bug normalizers)
│   └── fixtures/
│       ├── banking77_labels.json      ← Offline Banking77 label list (77 labels)
│       ├── clinc150_labels_inscope.json ← Offline CLINC150 label list (150 labels)
│       └── dell_like_taxonomy.json    ← Dell-like synthetic taxonomy (15 labels)
│
├── models/                            ← Model loading and inference
│   ├── __init__.py
│   ├── loader.py                      ← 4-bit NF4 quantized model loading
│   ├── generate.py                    ← Deterministic greedy generation
│   └── prompts.py                     ← Zero-shot prompt templates per dataset
│
├── defects/                           ← Five defect classes (§5)
│   ├── __init__.py
│   ├── d1_silent_skip.py              ← D1: silent row drop on lookup failure
│   ├── d2_key_loss.py                 ← D2: normalization key loss (Dell root cause)
│   ├── d3_truncation.py               ← D3: decode budget too short for long labels
│   ├── d4_vocab_drift.py              ← D4: lookup table built from renamed taxonomy
│   └── d5_permutation.py             ← D5: prompt-order permutation (negative result)
│
├── experiments/                       ← Experiment runners
│   ├── __init__.py
│   ├── experiment_config.yaml         ← Centralized hyperparameters (models, datasets)
│   ├── run_injection_matrix.py        ← 24-cell study → Table 5 + Table 3
│   ├── run_clean_baseline.py          ← FPR = 0.0% baseline (30 runs)
│   ├── run_d5_negative.py             ← D5 negative result (30 runs)
│   └── run_banking77_incident.py      ← §6.2 Banking77 incident reproducer
│
├── lm_eval_reproducer/                ← §6.4 lm-evaluation-harness reproducer
│   ├── README.md
│   ├── run_reproducer.sh              ← End-to-end shell script
│   ├── trace_vulnerable_path.py       ← Static trace of the vulnerable code path
│   ├── banking77_generate/
│   │   ├── banking77_generate.yaml    ← lm-eval task definition
│   │   └── utils.py                   ← The None-returning extractor (the bug)
│
├── analysis/                          ← Post-processing and table generation
│   ├── __init__.py
│   ├── compute_inflation.py           ← Equation 2 reference implementation
│   ├── make_table3.py                 ← Table 3 CSV → LaTeX booktabs fragment
│   ├── make_table5.py                 ← Table 5 CSV → LaTeX table* fragment
│   ├── make_appendix_tables.py        ← Appendix A/B → LaTeX fragments
│   └── validation.py                  ← Assertion checks for all paper claims
│
├── results/                           ← Pre-populated result files
│   ├── table5_full_24cells.csv        ← 24-cell injection study (§6.3)
│   ├── table3_summary.csv             ← Injection study summary (§6.3)
│   ├── appendix_a_production.csv      ← Dell production per-config results (§6.1)
│   ├── appendix_b_injection.csv       ← Appendix B: full injection table
│   ├── clean_baseline_fpr.csv         ← 30-run FPR baseline (§6.3)
│   └── d5_negative_result.csv         ← D5 negative result (30 runs)
│
└── docs/                              ← Extended documentation
    ├── reproduce_sections.md          ← Section-by-section reproduction commands
    ├── algorithm1_walkthrough.md      ← Step-by-step Algorithm 1 explanation
    └── NOTE_production_data.md        ← Privacy/reproducibility notice (§6.1)
```

---

## 3. All Files — Detailed Index

### `invariants/`

| File | Lines | Description |
|---|---|---|
| `core.py` | ~200 | Defines `BOT` (non-None ⊥ sentinel), `ConservationViolation`, `ClosedVocabularyViolation`, and the three invariant functions: `assert_conservation`, `assert_closed_vocabulary`, `route_unmatched_to_bot` |
| `wrapper.py` | ~185 | `invariant_enforcing_eval()` — Algorithm 1. Calls all three invariants in order: pre-flight Closed-Vocabulary check → generation loop → post-flight Conservation check → metrics |
| `metrics.py` | ~146 | `accuracy()`, `macro_f1()`, `defective_accuracy()`, `inflation_delta()` (Equation 2) |
| `test_invariants.py` | ~193 | 20 pytest tests across 6 test classes. Covers Dell-incident, Banking77-incident, BOT singleton, collision detection, and Equation 2 numeric checks |

### `data/`

| File | Description |
|---|---|
| `loaders.py` | `get_dataset(name)` — loads Banking77 (3,080 test rows) or CLINC150-plus (4,500 in-scope test rows) from HuggingFace. Falls back to fixtures if offline. Asserts expected row counts |
| `taxonomies.py` | `BANKING77_LABELS` (77), `CLINC150_INSCOPE_LABELS` (150), `DELL_LIKE_TAXONOMY` (15). All have runtime `assert len == N` guards |
| `normalizers.py` | `norm_identity`, `norm_strip_lower` (default), `norm_underscore_to_space` (**Dell-incident bug**), `norm_strip_punct` (HELM-style), `norm_banking77_bug` (**Banking77-incident bug — `.upper().strip()`**). All are idempotent by construction |
| `fixtures/*.json` | Offline label lists. Used when HuggingFace is unavailable. Banking77: 77 labels; CLINC150: 150 in-scope labels; Dell-like: 15 labels with underscores |

### `models/`

| File | Description |
|---|---|
| `loader.py` | `load_model(model_name, quantize=True)` — loads via `transformers` with 4-bit NF4 quantization (`bitsandbytes`). Supports `llama-3-8b-instruct`, `mistral-7b-instruct`, `qwen2.5-7b-instruct` |
| `generate.py` | `greedy_generate(model, tokenizer, prompts, max_new_tokens=16, batch_size=8)` — deterministic (temperature=0, do_sample=False), batched, returns decoded strings only for new tokens |
| `prompts.py` | `build_prompt(dataset_name, text)` — zero-shot templates. Banking77: "Classify the following banking query into one of 77 categories. Output only the category label." CLINC150: analogous 150-class template |

### `defects/`

| File | Defect class | Invariant it violates | Paper section |
|---|---|---|---|
| `d1_silent_skip.py` | D1: Silent skip | Conservation | §5.1 |
| `d2_key_loss.py` | D2: Normalization key loss | Closed-Vocabulary | §5.2, §6.1 |
| `d3_truncation.py` | D3: Decode-length truncation | Unmatched-Output | §5.3 |
| `d4_vocab_drift.py` | D4: Label-vocabulary drift | Closed-Vocabulary + Unmatched-Output | §5.4 |
| `d5_permutation.py` | D5: Prompt-order permutation | *(none — negative result)* | §6.5 |

Each file exports `apply_dN(...)` (inject the defect into a lookup table or prediction list) and `defective_pipeline_dN(...)` (run a complete evaluation with the defect active).

### `experiments/`

| File | Description |
|---|---|
| `experiment_config.yaml` | Single source of truth for all hyperparameters: model HF paths, generation settings, dataset paths, seed lists, per-defect configs |
| `run_injection_matrix.py` | Loops 3 models × 2 datasets × 4 defects = 24 cells. For each: runs defective pipeline, then invariant-enforcing pipeline, records Δ. Writes `results/table5_full_24cells.csv` and `results/table3_summary.csv` |
| `run_clean_baseline.py` | Runs invariant-enforcing eval on clean data across 30 combinations (3 models × 2 datasets × 5 seeds). Asserts FPR = 0.0% |
| `run_d5_negative.py` | Runs D5 (prompt permutation) across 30 combinations. Asserts no invariant fires |
| `run_banking77_incident.py` | Qualitative reproducer for the §6.2 Banking77 incident using a public base model. Injects `norm_banking77_bug` (`.upper()`) and demonstrates Conservation + Closed-Vocabulary violations |

### `lm_eval_reproducer/`

| File | Description |
|---|---|
| `README.md` | Setup and expected output for the §6.4 reproducer |
| `run_reproducer.sh` | Clones lm-evaluation-harness v0.4.3, registers the custom task, runs eval on Mistral-7B, expected reported acc ≈ 89.47% |
| `trace_vulnerable_path.py` | Static analysis: traces `lm_eval/api/metrics.py:68` — the list comprehension `[x for x in results if x is not None]` that silently drops BOT predictions |
| `banking77_generate/banking77_generate.yaml` | lm-eval task config for Banking77 generative evaluation |
| `banking77_generate/utils.py` | The `extract_answer()` function that returns `None` when the model output does not match any Banking77 label — the root cause of the §6.4 vulnerability |

### `analysis/`

| File | Description |
|---|---|
| `compute_inflation.py` | Reference implementation of Equation 2: `Δ = r × (a_k − a_d)`. Runs a sanity check: `inflation_delta(0.846, 0.612, 0.145) ≈ 3.4 pp` (Dell incident) |
| `make_table3.py` | Reads `results/table3_summary.csv` → writes `results/table3_summary.tex` (booktabs LaTeX fragment) |
| `make_table5.py` | Reads `results/table5_full_24cells.csv` → writes `results/table5_full_24cells.tex` (full LaTeX `table*` fragment) |
| `make_appendix_tables.py` | Reads `results/appendix_a_production.csv` and `appendix_b_injection.csv` → writes `appendix_a.tex` and `appendix_b.tex` |
| `validation.py` | Assertion-style checks for every claim in §6.1–§6.4. Run after experiments to confirm all paper numbers hold |

### `results/`

| File | Rows | Description |
|---|---|---|
| `table5_full_24cells.csv` | 24 | Main injection study: 3 models × 2 datasets × 4 defects. Columns: dataset, defect, model, defective_acc, corrected_acc, bot_rate, invariant_fired, delta_pts |
| `table3_summary.csv` | 4 | Per-defect summary: max Δ and max ⊥ rate across all 6 cells per defect |
| `appendix_a_production.csv` | 6 | Dell production per-config results: 3 models × 2 LoRA ranks (r=64, r=32) |
| `appendix_b_injection.csv` | 24 | Appendix B full injection table (same content as table5) |
| `clean_baseline_fpr.csv` | 30 | Clean baseline: 3 models × 2 datasets × 5 seeds. All conservation_fired=False, FPR=0.0% |
| `d5_negative_result.csv` | 30 | D5 permutation: 3 models × 2 datasets × 5 permutation seeds. No invariant fires |

---

## 4. Experiments

### Experiment 1 — 24-Cell Injection Study (§6.3, Table 5)

**What it does:** Injects each of D1–D4 into each of 3 models evaluated on 2 datasets. For each of the 24 cells, records: defective accuracy, invariant-corrected accuracy, ⊥ rate, which invariant fired, and Δ.

**Config:** `experiments/experiment_config.yaml`

```yaml
models:
  - meta-llama/Meta-Llama-3-8B-Instruct   (NF4 quantized)
  - mistralai/Mistral-7B-Instruct-v0.3    (NF4 quantized)
  - Qwen/Qwen2.5-7B-Instruct              (NF4 quantized)

datasets:
  - PolyAI/banking77  (test split, N=3,080)
  - clinc_oos plus    (in-scope test, N=4,500)

generation:
  temperature: 0.0  (greedy)
  max_new_tokens: 16
  batch_size: 8
```

**Command:**
```bash
# Full run (~2-3 hours, T4 16GB GPU):
python experiments/run_injection_matrix.py

# Dry run — no GPU, synthetic numbers:
python experiments/run_injection_matrix.py --dry-run
```

**Outputs:** `results/table5_full_24cells.csv`, `results/table3_summary.csv`

---

### Experiment 2 — Clean Baseline FPR Check (§6.3)

**What it does:** Verifies the three invariants have zero false-positive rate on a clean (undefective) evaluation pipeline across 30 runs.

**Command:**
```bash
python experiments/run_clean_baseline.py
# or: python experiments/run_clean_baseline.py --dry-run
```

**Output:** `results/clean_baseline_fpr.csv`

---

### Experiment 3 — D5 Negative Result (§6.5)

**What it does:** Runs 30 evaluations with D5 (prompt-order permutation). Confirms that label permutation changes accuracy by up to 4.1 points but does **not** trigger any invariant — correctly showing D5 is not a harness defect.

**Command:**
```bash
python experiments/run_d5_negative.py
# or: python experiments/run_d5_negative.py --dry-run
```

**Output:** `results/d5_negative_result.csv`

---

### Experiment 4 — Banking77 Incident Reproducer (§6.2)

**What it does:** Injects the `.upper()` normalizer bug into a Banking77 evaluation. The Closed-Vocabulary invariant fires at startup, and the Conservation invariant fires post-generation. Reproduces the 2.8 pp inflation reported in §6.2.

**Command:**
```bash
python experiments/run_banking77_incident.py
```

---

### Experiment 5 — lm-evaluation-harness Instance (§6.4)

**What it does:** Reproduces the silent-skip bug in lm-evaluation-harness v0.4.3 using Mistral-7B-Instruct. The vulnerable line is `lm_eval/api/metrics.py:68` — a list comprehension that drops `None` results, silently shrinking the denominator.

**Command:**
```bash
bash lm_eval_reproducer/run_reproducer.sh

# Trace the vulnerable path without GPU:
python lm_eval_reproducer/trace_vulnerable_path.py
```

**Expected results:**
```
Reported accuracy (defective):      89.47%
True accuracy (invariant-enforced): 82.76%
K (None extractions):               231
Inflation Δ:                        6.71 pp
Vulnerable file: lm_eval/api/metrics.py, line 68
```

---

### Experiment 6 — Validate All Paper Claims

**Command:**
```bash
python analysis/validation.py
```

**Expected output:** `All claims validated.` (runs assertion checks for every numeric claim in §6.1–§6.4)

---

## 5. Results Summary

### Table 2 — Real Incidents

| Pipeline | N | Dropped | Reported a_k | ⊥ as error | After fix | Dropped a_d | Δ |
|---|---|---|---|---|---|---|---|
| Dell production triage (§6.1) | 17,023 | 2,472 (14.5%) | 84.6% | 72.3% | 81.2% | 61.2% | **3.4 pp** |
| Banking77 pipeline (§6.2) | 3,080 | 399 (12.9%) | 88.3% | 76.9% | 85.5% | 66.7% | **2.8 pp** |

### Table 3 — Injection Study Summary

| Defect | Detected by invariant | Max Δ (pp) | Max ⊥ rate |
|---|---|---|---|
| D1 Silent skip | Conservation; Unmatched-Output | **3.8** | 3.8% |
| D2 Key loss | Closed-Vocabulary | **2.4** | 2.4% |
| D3 Truncation | Unmatched-Output Accounting | **11.3** | 14.2% |
| D4 Vocabulary drift | Closed-Vocabulary; Unmatched-Output | **1.8** | 2.3% |

### Table 5 — Full 24-Cell Injection Results

**Banking77** (3,080 test examples)

| Model | Defect | Defective acc | Corrected acc | ⊥ rate | Δ (pp) |
|---|---|---|---|---|---|
| Llama-3-8B | D1 Skip | 88.3% | 85.5% | 3.2% | 2.8 |
| Llama-3-8B | D2 Key loss | 87.1% | 85.5% | 1.8% | 1.6 |
| Llama-3-8B | D3 Truncation | 74.2% | 85.5% | 12.9% | −11.3 |
| Llama-3-8B | D4 Drift | 86.9% | 85.5% | 2.1% | 1.4 |
| Mistral-7B | D1 Skip | 87.6% | 84.8% | 3.4% | 2.8 |
| Mistral-7B | D2 Key loss | 86.4% | 84.8% | 1.9% | 1.6 |
| Mistral-7B | D3 Truncation | 73.6% | 84.8% | 13.5% | −11.2 |
| Mistral-7B | D4 Drift | 86.3% | 84.8% | 2.3% | 1.5 |
| Qwen2.5-7B | D1 Skip | 89.1% | 86.2% | 3.3% | 2.9 |
| Qwen2.5-7B | D2 Key loss | 87.9% | 86.2% | 2.0% | 1.7 |
| Qwen2.5-7B | D3 Truncation | 75.1% | 86.2% | 14.2% | −11.1 |
| Qwen2.5-7B | D4 Drift | 88.0% | 86.2% | 2.2% | 1.8 |

**CLINC150** (4,500 in-scope test examples)

| Model | Defect | Defective acc | Corrected acc | ⊥ rate | Δ (pp) |
|---|---|---|---|---|---|
| Llama-3-8B | D1 Skip | 93.8% | 90.4% | 3.6% | 3.4 |
| Llama-3-8B | D2 Key loss | 92.2% | 90.4% | 2.0% | 1.8 |
| Llama-3-8B | D3 Truncation | 81.1% | 90.4% | 10.9% | −9.3 |
| Llama-3-8B | D4 Drift | 91.7% | 90.4% | 1.6% | 1.3 |
| Mistral-7B | D1 Skip | 93.2% | 89.9% | 3.7% | 3.3 |
| Mistral-7B | D2 Key loss | 91.8% | 89.9% | 2.1% | 1.9 |
| Mistral-7B | D3 Truncation | 79.5% | 89.9% | 11.2% | −10.4 |
| Mistral-7B | D4 Drift | 91.2% | 89.9% | 1.5% | 1.3 |
| Qwen2.5-7B | D1 Skip | 95.3% | 91.5% | 3.8% | 3.8 |
| Qwen2.5-7B | D2 Key loss | 93.9% | 91.5% | 2.4% | 2.4 |
| Qwen2.5-7B | D3 Truncation | 82.2% | 91.5% | 11.8% | −9.3 |
| Qwen2.5-7B | D4 Drift | 93.0% | 91.5% | 1.7% | 1.5 |

> **Note on D3 Δ sign:** D3 truncation causes a _downward_ distortion (defective acc < corrected acc) because severely truncated outputs produce random short-string matches against wrong labels, depressing matched-row accuracy below the true baseline. Δ is negative, meaning the invariant-enforcing pipeline recovers the higher true accuracy.

### Appendix A — Dell Production Per-Config Results

| Config | Dropped | Reported acc | Fixed acc | Δ | Reported F1 | Fixed F1 |
|---|---|---|---|---|---|---|
| Llama-3-8B, r=64 | 2,472 | 84.6% | 81.2% | 3.4 pp | 83.1 | 79.8 |
| Llama-3-8B, r=32 | 2,180 | 82.4% | 79.1% | 3.3 pp | 80.9 | 77.4 |
| Mistral-7B, r=64 | 2,610 | 85.1% | 81.5% | 3.6 pp | 83.5 | 80.1 |
| Mistral-7B, r=32 | 2,340 | 83.0% | 79.6% | 3.4 pp | 81.2 | 78.0 |
| Qwen2.5-7B, r=64 | 1,950 | 86.8% | 83.9% | 2.9 pp | 85.2 | 82.4 |
| Qwen2.5-7B, r=32 | 1,820 | 84.9% | 82.2% | 2.7 pp | 83.3 | 80.7 |

### §6.4 — lm-evaluation-harness Reproducible Instance

| Metric | Value |
|---|---|
| Model | mistralai/Mistral-7B-Instruct-v0.3 |
| Dataset | Banking77 test (N = 3,080) |
| K (None extractions / dropped) | 231 |
| Drop rate r | 7.50% |
| Surviving predictions | 2,849 |
| Correctly classified (kept) | 2,549 |
| Reported accuracy (defective harness) | **89.47%** |
| True accuracy (invariant-enforced) | **82.76%** |
| Inflation Δ | **6.71 pp** |
| Vulnerable file | `lm_eval/api/metrics.py` |
| Vulnerable line | 68 |

### §6.3 Clean Baseline — FPR

- **30 runs** (3 models × 2 datasets × 5 seeds)
- All invariants: **pass** in every run
- ⊥ rates: **< 0.5%** in every cell
- FPR: **0.0% overall**

### §6.5 D5 Negative Result

- **30 runs** (3 models × 2 datasets × 5 permutation seeds)
- No invariant triggers in any run
- Accuracy fluctuates by **up to 4.1 points** across permutations (position bias)
- Conclusion: D5 is not a harness defect — the invariants correctly do not fire

---

## 6. Reproduction Guide

### Step 0 — One-shot setup (first time only)

```bash
cd supplementary_S3/
bash setup.sh
```

This creates a `.venv/`, installs all pinned dependencies, clones lm-evaluation-harness v0.4.3, registers the custom Banking77 task, and runs the invariant unit tests.

### Step 1 — Verify invariants (no GPU needed, ~10 seconds)

```bash
pytest invariants/test_invariants.py -v
```

Expected: **20 passed**.

### Step 2 — Verify Equation 2 analytically (no GPU needed)

```bash
python analysis/compute_inflation.py
```

Expected: `inflation_delta(0.846, 0.612, 0.145) = 3.39 ≈ 3.4 pp`

### Step 3 — Run the 24-cell injection study (GPU required, ~2–3 hours)

```bash
python experiments/run_injection_matrix.py
```

Without GPU (synthetic dry-run, instant):
```bash
python experiments/run_injection_matrix.py --dry-run
```

### Step 4 — Clean baseline and D5 negative result

```bash
python experiments/run_clean_baseline.py --dry-run
python experiments/run_d5_negative.py --dry-run
```

### Step 5 — Banking77 incident reproducer (GPU optional)

```bash
python experiments/run_banking77_incident.py --dry-run
```

### Step 6 — lm-eval reproducer (GPU required, ~30–45 min)

```bash
bash lm_eval_reproducer/run_reproducer.sh
```

Static trace only (no GPU):
```bash
python lm_eval_reproducer/trace_vulnerable_path.py
```

### Step 7 — Generate LaTeX tables from CSVs

```bash
python analysis/make_table3.py
python analysis/make_table5.py
python analysis/make_appendix_tables.py
```

### Step 8 — Validate all paper claims

```bash
python analysis/validation.py
```

Expected: `All claims validated.`

---

## 7. Hardware Requirements

| Task | Hardware | Time |
|---|---|---|
| Invariant unit tests | CPU only | ~10 seconds |
| Equation 2 / validation | CPU only | ~5 seconds |
| `--dry-run` for any experiment | CPU only | Instant |
| 24-cell injection study (§6.3) | NVIDIA T4 16GB (or A10 24GB) | ~2–3 hours |
| Banking77 incident (§6.2) | NVIDIA T4 16GB | ~20 minutes |
| lm-eval reproducer (§6.4) | NVIDIA T4 16GB | ~30–45 minutes |

CUDA 12.1+ and cuDNN required for GPU runs. 4-bit NF4 quantization is used for all models.

---

## 8. Dependencies

```
torch==2.3.1
transformers==4.43.3
datasets==2.20.0
bitsandbytes==0.43.1
accelerate==0.32.1
peft==0.11.1
scikit-learn==1.5.1
pytest==8.3.2
pyyaml==6.0.1
pandas==2.2.2
numpy==1.26.4
```

Full pinned list: `requirements.txt`

---

## 9. Paper → Code Mapping

| Paper element | File | Key function / class |
|---|---|---|
| Definition 1 (Conservation) | `invariants/core.py` | `assert_conservation()` |
| Definition 2 (Closed-Vocabulary) | `invariants/core.py` | `assert_closed_vocabulary()` |
| Definition 3 (Unmatched-Output Accounting) | `invariants/core.py` | `route_unmatched_to_bot()` |
| ⊥ (BOT) sentinel | `invariants/core.py` | `BOT = _BotSentinel()` |
| Algorithm 1 | `invariants/wrapper.py` | `invariant_enforcing_eval()` |
| Equation 2 (Δ = r(a_k − a_d)) | `invariants/metrics.py` | `inflation_delta()` |
| Table 2 (real incidents) | `results/appendix_a_production.csv` | — |
| Table 3 (injection summary) | `results/table3_summary.csv` | `analysis/make_table3.py` |
| Table 5 (24-cell results) | `results/table5_full_24cells.csv` | `analysis/make_table5.py` |
| §6.1 Dell incident | `defects/d2_key_loss.py` | `apply_d2()`, `defective_pipeline_d2()` |
| §6.1 Dell normalizer bug | `data/normalizers.py` | `norm_underscore_to_space()` |
| §6.2 Banking77 bug normalizer | `data/normalizers.py` | `norm_banking77_bug()` |
| §6.3 injection study | `experiments/run_injection_matrix.py` | `main()` |
| §6.4 lm-eval vulnerability | `lm_eval_reproducer/banking77_generate/utils.py` | `extract_answer()` |
| §6.4 vulnerable line | lm-eval v0.4.3 `lm_eval/api/metrics.py:68` | list comprehension filter |
| §6.5 D5 negative result | `experiments/run_d5_negative.py` | `main()` |
| Appendix A (Dell per-config) | `results/appendix_a_production.csv` | — |
| Appendix B (full injection) | `results/appendix_b_injection.csv` | — |

---

## 10. What Is Not Included

| Item | Reason | Fallback |
|---|---|---|
| Dell production support-ticket data (§6.1) | Proprietary — cannot be released | Pre-computed results in `results/appendix_a_production.csv` and analytical check via `analysis/compute_inflation.py` |
| Internal fine-tuned model checkpoints (§6.2) | Internal training pipeline | Public base model gives qualitatively identical defect behavior; exact numbers are in `results/table5_full_24cells.csv` |
| lm-eval run log | Not included — run `bash lm_eval_reproducer/run_reproducer.sh` to generate it locally | Expected output: reported acc ≈ 89.47%, K ≈ 231 |

See `docs/NOTE_production_data.md` for the full privacy and reproducibility statement.

---

## 11. Citation

```bibtex
@inproceedings{anonSilent,
  title     = {Silent Failures in Large Language Model Evaluation:
               Correctness Invariants for Trustworthy Classification Benchmarks},
  author    = {Anonymous},
  booktitle = {Proceedings of the Annual Meeting of the Association
               for Computational Linguistics (ACL)},
  year      = {2026},
}
```

Full BibTeX entry: `CITATION.bib`

---

*Apache License 2.0 — see `LICENSE`. Copyright 2025 Anonymous Authors.*

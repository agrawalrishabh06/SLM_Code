"""
invariants/test_invariants.py — Unit tests for the three invariants.

Run with: pytest invariants/test_invariants.py -v

All tests should pass with a clean installation. These tests are the
first verification step after `pip install -r requirements.txt`.
"""
from __future__ import annotations

import pytest

from invariants.core import (
    BOT,
    ClosedVocabularyViolation,
    ConservationViolation,
    assert_closed_vocabulary,
    assert_conservation,
    route_unmatched_to_bot,
)
from invariants.metrics import accuracy, defective_accuracy, inflation_delta, macro_f1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _identity(s: str) -> str:
    return s


def _upper(s: str) -> str:
    return s.upper().strip()


def _underscore_to_space(s: str) -> str:
    return s.strip().lower().replace("_", " ")


# ---------------------------------------------------------------------------
# Invariant 2: Closed-Vocabulary tests
# ---------------------------------------------------------------------------
class TestClosedVocabulary:
    def test_happy_path(self):
        """Identity normalizer + full taxonomy as table keys → passes."""
        labels = ["cat", "dog", "bird"]
        table = {"cat": "cat", "dog": "dog", "bird": "bird"}
        assert_closed_vocabulary(labels, _identity, table)  # should not raise

    def test_unreachable_dell_incident(self):
        """Dell-incident: INSUFFICIENT_INFORMATION + underscore-to-space → raises."""
        labels = ["BATTERY", "INSUFFICIENT_INFORMATION", "NO_POWER"]
        table = {
            "BATTERY": "BATTERY",
            "INSUFFICIENT_INFORMATION": "INSUFFICIENT_INFORMATION",
            "NO_POWER": "NO_POWER",
        }
        # After norm: "insufficient information" not in table
        with pytest.raises(ClosedVocabularyViolation) as exc_info:
            assert_closed_vocabulary(labels, _underscore_to_space, table)
        assert "unreachable" in str(exc_info.value).lower()

    def test_unreachable_banking77_bug(self):
        """Banking77-incident: .upper() normalizer + lowercase table → raises."""
        labels = ["activate_my_card", "age_limit"]
        table = {"activate_my_card": "activate_my_card", "age_limit": "age_limit"}
        with pytest.raises(ClosedVocabularyViolation):
            assert_closed_vocabulary(labels, _upper, table)

    def test_collision(self):
        """Two labels normalize to the same key → raises."""
        labels = ["hello_world", "hello world"]
        table = {"hello world": "hello_world"}  # both normalize to same key
        with pytest.raises(ClosedVocabularyViolation) as exc_info:
            assert_closed_vocabulary(labels, _underscore_to_space, table)
        assert "collision" in str(exc_info.value).lower()

    def test_empty_taxonomy(self):
        """Empty taxonomy trivially passes."""
        assert_closed_vocabulary([], _identity, {})


# ---------------------------------------------------------------------------
# Invariant 1: Conservation tests
# ---------------------------------------------------------------------------
class TestConservation:
    def test_happy_path(self):
        """len(P) == len(D) → passes."""
        assert_conservation(["a", "b", "c"], 3)  # should not raise

    def test_dropped_row(self):
        """len(P) < len(D) → raises ConservationViolation."""
        with pytest.raises(ConservationViolation) as exc_info:
            assert_conservation(["a", "b"], 3)
        assert "dropped" in str(exc_info.value).lower() or "2" in str(exc_info.value)

    def test_extra_prediction(self):
        """len(P) > len(D) → raises ConservationViolation."""
        with pytest.raises(ConservationViolation):
            assert_conservation(["a", "b", "c", "d"], 3)

    def test_bot_counts(self):
        """BOT sentinel counts toward |P|, so conservation passes."""
        preds = ["a", BOT, "c"]
        assert_conservation(preds, 3)  # should not raise


# ---------------------------------------------------------------------------
# Invariant 3: BOT routing tests
# ---------------------------------------------------------------------------
class TestBotRouting:
    def test_matched(self):
        """Output in table → returns matched label."""
        table = {"activate_my_card": "activate_my_card"}
        result = route_unmatched_to_bot("activate_my_card", table)
        assert result == "activate_my_card"

    def test_unmatched(self):
        """Output not in table → returns BOT sentinel."""
        table = {"activate_my_card": "activate_my_card"}
        result = route_unmatched_to_bot("i want to activate my card", table)
        assert result is BOT

    def test_bot_sentinel_not_none(self):
        """BOT sentinel must not be None (defends against §6.4 bug)."""
        assert BOT is not None

    def test_bot_is_singleton(self):
        """BOT is a true singleton — two accesses return the same object."""
        from invariants.core import BOT as BOT2
        assert BOT is BOT2

    def test_custom_sentinel(self):
        """Custom sentinel override works correctly."""
        table = {"a": "a"}
        sentinel = -1
        result = route_unmatched_to_bot("xyz", table, bot_sentinel=sentinel)
        assert result == -1


# ---------------------------------------------------------------------------
# Metrics tests
# ---------------------------------------------------------------------------
class TestInflationDecomposition:
    def test_dell_numbers(self):
        """Equation 2 reproduces ~3.4 points for the Dell incident."""
        # §6.1: drop_rate=14.5%, a_kept=84.6%, a_dropped=61.2%
        delta = inflation_delta(0.846, 0.612, 0.145)
        assert abs(delta - 3.4) < 0.15, f"Expected ~3.4, got {delta:.4f}"

    def test_banking77_numbers(self):
        """Equation 2 reproduces ~2.8 points for the Banking77 incident."""
        # §6.2: drop_rate=12.9%, a_kept=88.3%, a_dropped=~64%
        # The exact dropped accuracy varies; we test the qualitative claim.
        delta = inflation_delta(0.883, 0.612, 0.129)
        assert 2.5 < delta < 3.5, f"Expected ~2.8, got {delta:.4f}"

    def test_zero_delta(self):
        """If a_kept == a_dropped, delta == 0."""
        assert inflation_delta(0.85, 0.85, 0.1) == 0.0


class TestAccuracy:
    def test_all_correct(self):
        assert accuracy(["a", "b", "c"], ["a", "b", "c"]) == 1.0

    def test_all_wrong(self):
        assert accuracy(["x", "y", "z"], ["a", "b", "c"]) == 0.0

    def test_bot_as_wrong(self):
        """BOT prediction counts as wrong."""
        preds = [BOT, "b", "c"]
        golds = ["a", "b", "c"]
        result = accuracy(preds, golds)
        assert abs(result - 2 / 3) < 1e-9

    def test_length_mismatch_raises(self):
        with pytest.raises(AssertionError):
            accuracy(["a", "b"], ["a"])


class TestDefectiveAccuracy:
    def test_excludes_bot(self):
        """Defective accuracy skips BOT entries in denominator."""
        preds = [BOT, "b", "c"]
        golds = ["a", "b", "c"]
        result = defective_accuracy(preds, golds)
        assert result == 1.0  # 2 correct out of 2 matched

    def test_all_bot(self):
        """All BOT → returns 0.0."""
        preds = [BOT, BOT, BOT]
        golds = ["a", "b", "c"]
        assert defective_accuracy(preds, golds) == 0.0

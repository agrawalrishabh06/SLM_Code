"""
analysis/validation.py — Assertion-style sanity checks for paper claims.

Run this before paper submission to verify that all computed results match
the claimed numbers. Any divergence raises AssertionError.

Usage:
    python analysis/validation.py

Expected: all assertions pass, "All claims validated." printed.
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "results"


def assert_close(name: str, actual: float, expected: float, tol: float = 0.1) -> None:
    assert abs(actual - expected) <= tol, (
        f"{name}: expected {expected} ± {tol}, got {actual}"
    )
    print(f"  ✓ {name}: {actual:.2f} (expected {expected} ± {tol})")


def assert_in_range(name: str, actual: float, lo: float, hi: float) -> None:
    assert lo <= actual <= hi, (
        f"{name}: expected [{lo}, {hi}], got {actual}"
    )
    print(f"  ✓ {name}: {actual:.2f} (expected [{lo}, {hi}])")


def _read_csv(path: Path) -> list:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def validate_paper_claims() -> None:
    """Compare computed results against paper claims. Raise AssertionError on divergence."""
    errors = []

    print("Validating paper claims...")

    # ------------------------------------------------------------------
    # §6.1 Production triage (Dell incident)
    # ------------------------------------------------------------------
    appendix_a_path = RESULTS_DIR / "appendix_a_production.csv"
    if appendix_a_path.exists():
        rows = _read_csv(appendix_a_path)
        # Look for the Dell-specific row
        dell_rows = [r for r in rows if "dell" in str(r).lower() or "insufficient" in str(r).lower()]
        if dell_rows:
            try:
                row = dell_rows[0]
                delta_dell = float(row.get("delta_pts", row.get("delta", 0)))
                assert_close("§6.1 Dell Δ", delta_dell, 3.4, tol=0.2)
            except (AssertionError, KeyError, ValueError) as e:
                errors.append(f"§6.1 Dell Δ: {e}")
    else:
        print("  SKIP §6.1: appendix_a_production.csv not found")

    # ------------------------------------------------------------------
    # §6.2 Banking77 incident
    # ------------------------------------------------------------------
    b77_incident_path = RESULTS_DIR / "banking77_incident.csv"
    if b77_incident_path.exists():
        rows = _read_csv(b77_incident_path)
        if rows:
            row = rows[0]
            try:
                assert_close("§6.2 Banking77 defective_acc", float(row["defective_acc"]), 88.3, tol=2.0)
                assert_close("§6.2 Banking77 true_acc", float(row["true_acc"]), 85.5, tol=2.0)
                assert_close("§6.2 Banking77 bot_rate", float(row["bot_rate"]), 12.9, tol=2.0)
            except (AssertionError, KeyError, ValueError) as e:
                errors.append(f"§6.2: {e}")
    else:
        print("  SKIP §6.2: banking77_incident.csv not found")

    # ------------------------------------------------------------------
    # §6.3 Injection study — max Δ for D3
    # ------------------------------------------------------------------
    table3_path = RESULTS_DIR / "table3_summary.csv"
    if table3_path.exists():
        rows = _read_csv(table3_path)
        d3_rows = [r for r in rows if r.get("defect") == "D3"]
        if d3_rows:
            try:
                max_delta_d3 = float(d3_rows[0]["max_delta_pts"])
                assert_in_range("§6.3 D3 max_delta", max_delta_d3, 8.0, 16.0)
            except (AssertionError, KeyError, ValueError) as e:
                errors.append(f"§6.3 D3 max_delta: {e}")
    else:
        print("  SKIP §6.3: table3_summary.csv not found")

    # Table5 row count
    table5_path = RESULTS_DIR / "table5_full_24cells.csv"
    if table5_path.exists():
        rows = _read_csv(table5_path)
        try:
            assert len(rows) == 24, f"Expected 24 rows in table5, got {len(rows)}"
            print(f"  ✓ §6.3 Table 5 row count: {len(rows)} (expected 24)")
        except AssertionError as e:
            errors.append(str(e))
    else:
        print("  SKIP §6.3: table5_full_24cells.csv not found")

    # ------------------------------------------------------------------
    # Clean baseline FPR = 0.0%
    # ------------------------------------------------------------------
    fpr_path = RESULTS_DIR / "clean_baseline_fpr.csv"
    if fpr_path.exists():
        rows = _read_csv(fpr_path)
        try:
            assert len(rows) == 30, f"Expected 30 rows in FPR CSV, got {len(rows)}"
            any_fired = any(
                r["conservation_fired"].lower() == "true" or
                r["closed_vocab_fired"].lower() == "true"
                for r in rows
            )
            assert not any_fired, "An invariant fired on a clean run — FPR is non-zero!"
            fpr = sum(float(r["fpr_contribution"]) for r in rows) / len(rows)
            assert fpr == 0.0, f"FPR = {fpr:.4f} (expected 0.0)"
            print(f"  ✓ Clean baseline FPR: {fpr:.4f} (expected 0.0)")
        except AssertionError as e:
            errors.append(f"FPR: {e}")
    else:
        print("  SKIP FPR: clean_baseline_fpr.csv not found")

    # ------------------------------------------------------------------
    # D5 negative result — no invariant fires
    # ------------------------------------------------------------------
    d5_path = RESULTS_DIR / "d5_negative_result.csv"
    if d5_path.exists():
        rows = _read_csv(d5_path)
        try:
            assert all(r["conservation_fired"].lower() == "false" for r in rows), \
                "Conservation fired in a D5 run!"
            assert all(r["closed_vocab_fired"].lower() == "false" for r in rows), \
                "Closed-Vocabulary fired in a D5 run!"
            accs = [float(r["accuracy"]) for r in rows]
            max_range = max(accs) - min(accs)
            print(f"  ✓ D5 negative: no invariant fired, max acc range = {max_range:.1f} pp")
        except AssertionError as e:
            errors.append(f"D5: {e}")
    else:
        print("  SKIP D5: d5_negative_result.csv not found")

    # ------------------------------------------------------------------
    # §6.4 lm_eval reproducer — validated analytically (log not bundled)
    # Run `bash lm_eval_reproducer/run_reproducer.sh` to generate the log.
    # ------------------------------------------------------------------
    # Analytical check: verify the §6.4 numbers are internally consistent
    n_total = 3080
    k_dropped = 231
    n_surviving = n_total - k_dropped          # 2849
    n_correct = 2549
    reported_acc = n_correct / n_surviving     # 0.8947...
    true_acc = n_correct / n_total             # 0.8276...
    delta = (reported_acc - true_acc) * 100    # 6.71 pp
    assert abs(reported_acc - 0.8947) < 0.001, f"§6.4 reported_acc={reported_acc:.4f}"
    assert abs(true_acc - 0.8276) < 0.001, f"§6.4 true_acc={true_acc:.4f}"
    assert abs(delta - 6.71) < 0.01, f"§6.4 delta={delta:.2f}"
    print(f"  ✓ §6.4 reported acc={reported_acc:.4f}, true acc={true_acc:.4f}, Δ={delta:.2f} pp (analytically verified)")

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    if errors:
        print(f"\n{len(errors)} claim(s) FAILED:")
        for err in errors:
            print(f"  ✗ {err}")
        sys.exit(1)
    else:
        print("\nAll claims validated.")


if __name__ == "__main__":
    validate_paper_claims()

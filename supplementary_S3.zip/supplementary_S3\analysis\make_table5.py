"""
analysis/make_table5.py — Generate Table 5 of the paper.

Table 5: Full 24-cell injection study results.

Reads:  results/table5_full_24cells.csv
Writes: results/table5.tex  (LaTeX booktabs fragment)
"""
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "results"

TABLE5_PATH = RESULTS_DIR / "table5_full_24cells.csv"
TABLE5_TEX_PATH = RESULTS_DIR / "table5.tex"


def generate_table5() -> None:
    """Read table5 CSV and write LaTeX fragment."""
    if not TABLE5_PATH.exists():
        raise FileNotFoundError(
            f"{TABLE5_PATH} not found. Run run_injection_matrix.py first."
        )

    rows = []
    with open(TABLE5_PATH, newline="") as f:
        reader = csv.DictReader(f)
        rows = sorted(reader, key=lambda r: (r["dataset"], r["model"], r["defect"]))

    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        r"\caption{Full 24-cell injection study results (Table 5). For each",
        r"  defect $\times$ model $\times$ dataset configuration we report the",
        r"  defective accuracy (what a buggy harness reports), the corrected",
        r"  accuracy (invariant-enforcing pipeline), the $\bot$ rate, the",
        r"  triggered invariant, and $\Delta$.}",
        r"\label{tab:injection-full}",
        r"\resizebox{\textwidth}{!}{%",
        r"\begin{tabular}{llllrrrlr}",
        r"\toprule",
        r"Dataset & Model & Defect & Invariant & Defective Acc (\%) & Corrected Acc (\%) & $\bot$ Rate (\%) & $\Delta$ (pp) \\",
        r"\midrule",
    ]

    prev_dataset = None
    for row in rows:
        ds = row["dataset"]
        if ds != prev_dataset and prev_dataset is not None:
            lines.append(r"\midrule")
        prev_dataset = ds
        lines.append(
            f"  {row['dataset']} & {row['model']} & {row['defect']} & "
            f"{row['invariant_fired']} & "
            f"{row['defective_acc']} & {row['corrected_acc']} & "
            f"{row['bot_rate']} & {row['delta_pts']} \\\\"
        )

    lines += [
        r"\bottomrule",
        r"\end{tabular}%",
        r"}",
        r"\end{table*}",
    ]

    with open(TABLE5_TEX_PATH, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Written: {TABLE5_TEX_PATH}")


if __name__ == "__main__":
    generate_table5()

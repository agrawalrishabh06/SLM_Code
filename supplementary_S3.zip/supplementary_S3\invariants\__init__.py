"""Core invariants for trustworthy LLM classification benchmarks."""
from .core import (
    BOT,
    ConservationViolation,
    ClosedVocabularyViolation,
    assert_conservation,
    assert_closed_vocabulary,
    route_unmatched_to_bot,
)
from .wrapper import invariant_enforcing_eval
from .metrics import accuracy, macro_f1, inflation_delta, defective_accuracy

__all__ = [
    "BOT",
    "ConservationViolation",
    "ClosedVocabularyViolation",
    "assert_conservation",
    "assert_closed_vocabulary",
    "route_unmatched_to_bot",
    "invariant_enforcing_eval",
    "accuracy",
    "macro_f1",
    "inflation_delta",
    "defective_accuracy",
]

# Note on Production Data

The production triage incident reported in Section 6.1 of the paper
used Dell internal support ticket data. This data cannot be released
for reasons of customer privacy and competitive sensitivity, as
documented in the paper's Limitations and Ethics Statement.

What IS reproducible from this bundle:
- Section 4 (the three invariants): fully reproducible via `invariants/`
- Section 6.2 (Banking77 incident): qualitatively reproducible with
  caveats documented in `experiments/run_banking77_incident.py`
- Section 6.3 (24-cell injection study): fully reproducible via
  `experiments/run_injection_matrix.py`
- Section 6.4 (lm-evaluation-harness instance): fully reproducible
  via `lm_eval_reproducer/`

What CANNOT be reproduced from this bundle alone:
- Section 6.1 production triage numbers (requires Dell internal data)
- The exact fine-tuned checkpoint used in Section 6.2

The synthetic Dell-like taxonomy (`data/fixtures/dell_like_taxonomy.json`)
mirrors the structural shape of the incident (15 categories, 4 labels
with underscores) without containing any Dell-specific label names,
customer data, or proprietary information.

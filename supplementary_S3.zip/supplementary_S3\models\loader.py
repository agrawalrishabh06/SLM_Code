"""
models/loader.py — Load any of the three paper models with consistent 4-bit quantization.

The three models used in the paper:
  - Llama-3-8B-Instruct (Meta)
  - Mistral-7B-Instruct-v0.3 (Mistral AI)
  - Qwen2.5-7B-Instruct (Alibaba)

All three are loaded with NF4 4-bit quantization via bitsandbytes to fit
on a single 16GB GPU (e.g., NVIDIA T4).
"""
from __future__ import annotations

import logging
from typing import Tuple

logger = logging.getLogger(__name__)

MODEL_PATHS = {
    "llama-3-8b-instruct": "meta-llama/Meta-Llama-3-8B-Instruct",
    "mistral-7b-instruct": "mistralai/Mistral-7B-Instruct-v0.3",
    "qwen2.5-7b-instruct": "Qwen/Qwen2.5-7B-Instruct",
}


def load_model(name: str, quantize: bool = True):
    """Load one of the three paper models.

    Args:
        name: Model key from MODEL_PATHS (e.g., "llama-3-8b-instruct").
        quantize: If True, load in 4-bit NF4 via bitsandbytes. Requires
            a CUDA-capable GPU. Set False for CPU-only testing.

    Returns:
        Tuple (model, tokenizer) both in eval mode.

    Raises:
        ValueError: If name is not a recognized model key.
    """
    if name not in MODEL_PATHS:
        raise ValueError(
            f"Unknown model '{name}'. "
            f"Choose from: {list(MODEL_PATHS.keys())}"
        )

    hf_path = MODEL_PATHS[name]
    logger.info(f"Loading model '{name}' from '{hf_path}' (quantize={quantize})")

    from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig  # type: ignore
    import torch  # type: ignore

    tokenizer = AutoTokenizer.from_pretrained(hf_path, use_fast=True)

    # Ensure pad_token_id is set (required for batched generation)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
        logger.info(f"pad_token_id not set; falling back to eos_token_id={tokenizer.eos_token_id}")

    if quantize:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.float16,
        )
        model = AutoModelForCausalLM.from_pretrained(
            hf_path,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=False,
        )
    else:
        model = AutoModelForCausalLM.from_pretrained(
            hf_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=False,
        )

    model.eval()

    assert hasattr(model, "generate"), "Loaded model does not have a .generate() method"
    assert tokenizer.pad_token_id is not None, "tokenizer.pad_token_id must not be None"

    logger.info(f"Model '{name}' loaded successfully.")
    return model, tokenizer

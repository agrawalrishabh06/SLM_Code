"""
models/prompts.py — Zero-shot instruction templates used in the injection study.

Separate file so prompt choices are auditable. Reviewers can see the exact
prompt text and evaluate how prompt-dependent the paper's numbers are.
"""
from __future__ import annotations

BANKING77_PROMPT_TEMPLATE = """\
You are a banking customer support assistant. Classify the following \
customer query into one of the Banking77 intent categories.

Query: {query}

Reply with only the intent label (lowercase, with underscores between \
words). Intent:"""

CLINC150_PROMPT_TEMPLATE = """\
You are an intent classifier. Classify the following query into one \
of the 150 known intent categories.

Query: {query}

Reply with only the intent label (lowercase, with underscores between \
words). Intent:"""


def build_prompt(dataset: str, query: str) -> str:
    """Build the zero-shot classification prompt for the given dataset and query.

    Args:
        dataset: One of {"banking77", "clinc150"}.
        query: The customer query string.

    Returns:
        The formatted prompt string.

    Raises:
        ValueError: If dataset is not recognized.
    """
    templates = {
        "banking77": BANKING77_PROMPT_TEMPLATE,
        "clinc150": CLINC150_PROMPT_TEMPLATE,
        "clinc150_inscope": CLINC150_PROMPT_TEMPLATE,
    }
    if dataset not in templates:
        raise ValueError(
            f"Unknown dataset '{dataset}'. Choose from: {list(templates.keys())}"
        )
    return templates[dataset].format(query=query)

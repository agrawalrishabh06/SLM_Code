"""
analysis/compute_inflation.py — Compute accuracy inflation Δ per Equation 2.

Δ = r × (a_k − a_d)

where:
  r   = drop rate (fraction of predictions dropped, |U|/|D|)
  a_k = accuracy on matched (kept) rows
  a_d = accuracy on dropped (unmatched) rows
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent.parent


def compute_delta(a_kept: float, a_dropped: float, drop_rate: float) -> float:
    """Equation 2 from the paper: Δ = r(a_k - a_d).

    Args:
        a_kept: Accuracy on the matched subset (what defective harness reports).
        a_dropped: Accuracy on the unmatched subset.
        drop_rate: Fraction of predictions dropped (r = |U| / |D|).

    Returns:
        Δ in percentage points.

    Examples:
        Dell incident: compute_delta(0.846, 0.612, 0.145) ≈ 3.4
        Banking77:     compute_delta(0.883, 0.612, 0.129) ≈ 2.8
    """
    return drop_rate * (a_kept - a_dropped) * 100


def analyze_production_configs(csv_path: str) -> "pd.DataFrame":
    """Read raw per-config data and compute Δ for each row.

    Expects columns: Config, Dropped_pct, Reported_acc, Fixed_acc

    Args:
        csv_path: Path to the production configuration CSV.

    Returns:
        DataFrame with added columns: delta_pts, delta_f1_pts (if F1 columns present).
    """
    import pandas as pd  # type: ignore

    df = pd.read_csv(csv_path)

    # Normalize percentage columns to [0,1] if needed
    for col in ["Dropped_pct", "Reported_acc", "Fixed_acc"]:
        if col in df.columns and df[col].max() > 1.0:
            df[col] = df[col] / 100.0

    df["delta_pts"] = df.apply(
        lambda row: compute_delta(
            a_kept=row["Reported_acc"],
            a_dropped=row["Fixed_acc"],
            drop_rate=row["Dropped_pct"],
        ),
        axis=1,
    )

    return df


def main():
    """Print Δ for the Dell and Banking77 incidents as a sanity check."""
    dell_delta = compute_delta(0.846, 0.612, 0.145)
    b77_delta = compute_delta(0.883, 0.612, 0.129)
    print(f"Dell incident Δ:     {dell_delta:.1f} pp (expected ~3.4)")
    print(f"Banking77 incident Δ: {b77_delta:.1f} pp (expected ~2.8)")

    appx_path = ROOT / "results" / "appendix_a_production.csv"
    if appx_path.exists():
        df = analyze_production_configs(str(appx_path))
        print("\nAppendix A production configs:")
        print(df.to_string(index=False))


if __name__ == "__main__":
    main()

"""
experiments/run_injection_matrix.py — The 24-cell injection study from §6.3.

Loops over:
  - 3 models × 2 datasets × 4 defects = 24 configurations

For each cell:
  1. Run the defective pipeline (D1/D2/D3/D4)
  2. Run the invariant-enforcing pipeline
  3. Record: defective acc, corrected acc, ⊥ rate, invariant fired, Δ

Writes:
  - results/table5_full_24cells.csv (24 rows)
  - results/table3_summary.csv (4 rows, one per defect)
  - results/logs/injection_run_<timestamp>.log

Hardware: NVIDIA T4 16GB (or A10 24GB). ~2-3 hours total.

Usage:
    python experiments/run_injection_matrix.py
    python experiments/run_injection_matrix.py --dry-run  # no GPU needed
"""
from __future__ import annotations

import argparse
import csv
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

# Ensure project root is on PYTHONPATH
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

RESULTS_DIR = ROOT / "results"
LOGS_DIR = RESULTS_DIR / "logs"
RESULTS_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

TABLE5_PATH = RESULTS_DIR / "table5_full_24cells.csv"
TABLE3_PATH = RESULTS_DIR / "table3_summary.csv"

TABLE5_FIELDS = [
    "dataset", "defect", "model",
    "defective_acc", "corrected_acc",
    "bot_rate", "invariant_fired", "delta_pts",
]

CONFIG_PATH = Path(__file__).parent / "experiment_config.yaml"


def load_config() -> Dict:
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


def _invariant_fired_for_defect(defect: str) -> str:
    """Return which invariant is triggered by each defect (for reporting)."""
    mapping = {
        "D1": "Conservation",
        "D2": "Closed-Vocabulary",
        "D3": "Unmatched-Output",
        "D4": "Unmatched-Output",
    }
    return mapping[defect]


def run_cell_dry(
    model_name: str,
    dataset_name: str,
    defect: str,
    config: Dict,
) -> Dict[str, Any]:
    """Dry-run: return plausible synthetic numbers without GPU."""
    import random
    rng = random.Random(hash((model_name, dataset_name, defect)) % (2**32))

    base_acc = rng.uniform(0.82, 0.90)
    drop_rate = {"D1": 0.032, "D2": 0.018, "D3": 0.45, "D4": 0.065}[defect]
    defective_acc = base_acc + drop_rate * rng.uniform(0.2, 0.4)
    defective_acc = min(defective_acc, 0.98)
    corrected_acc = defective_acc - drop_rate * rng.uniform(0.15, 0.35)
    delta = (defective_acc - corrected_acc) * 100

    return {
        "dataset": dataset_name,
        "defect": defect,
        "model": model_name,
        "defective_acc": round(defective_acc * 100, 1),
        "corrected_acc": round(corrected_acc * 100, 1),
        "bot_rate": round(drop_rate * 100, 1),
        "invariant_fired": _invariant_fired_for_defect(defect),
        "delta_pts": round(delta, 1),
    }


def run_cell(
    model,
    tokenizer,
    model_name: str,
    test_set: List[Dict],
    dataset_name: str,
    defect: str,
    config: Dict,
) -> Dict[str, Any]:
    """Run one cell of the injection matrix (live GPU run)."""
    from data.taxonomies import get_taxonomy  # type: ignore
    from data.normalizers import norm_strip_lower  # type: ignore
    from invariants.core import (  # type: ignore
        BOT, assert_closed_vocabulary, ClosedVocabularyViolation,
        route_unmatched_to_bot,
    )
    from invariants.wrapper import build_lookup_table, invariant_enforcing_eval  # type: ignore
    from defects import (  # type: ignore
        defective_pipeline_d1, defective_pipeline_d2,
        defective_pipeline_d3, defective_pipeline_d4,
    )

    taxonomy = get_taxonomy(dataset_name)
    normalizer = norm_strip_lower
    lookup_table = build_lookup_table(taxonomy, normalizer)

    dcfg = config.get("generation", {})
    batch_size = dcfg.get("batch_size", 8)
    max_new_tokens = dcfg.get("max_new_tokens", 16)

    logger.info(f"Running defective pipeline: {defect} / {dataset_name} / {model_name}")

    # --- Defective run ---
    if defect == "D1":
        defect_result = defective_pipeline_d1(
            model, tokenizer, test_set, taxonomy, normalizer, lookup_table,
            batch_size=batch_size, max_new_tokens=max_new_tokens,
            dataset_name=dataset_name,
        )
    elif defect == "D2":
        from data.normalizers import norm_underscore_to_space  # type: ignore
        defect_result = defective_pipeline_d2(
            model, tokenizer, test_set, taxonomy,
            normalizer=norm_underscore_to_space,
            batch_size=batch_size, max_new_tokens=max_new_tokens,
            dataset_name=dataset_name,
        )
    elif defect == "D3":
        defect_result = defective_pipeline_d3(
            model, tokenizer, test_set, taxonomy, normalizer, lookup_table,
            truncation_tokens=config.get("defect_configs", {}).get("d3_truncation", {}).get("max_new_tokens", 5),
            dataset_name=dataset_name,
        )
    elif defect == "D4":
        n_renames = config.get("defect_configs", {}).get("d4_vocab_drift", {}).get("n_renames", 5)
        defect_result = defective_pipeline_d4(
            model, tokenizer, test_set, taxonomy, normalizer,
            n_renames=n_renames,
            batch_size=batch_size, max_new_tokens=max_new_tokens,
            dataset_name=dataset_name,
        )
    else:
        raise ValueError(f"Unknown defect: {defect}")

    defective_acc = defect_result["defective_acc"]

    # --- Invariant-enforcing run ---
    logger.info(f"Running invariant-enforcing pipeline: {defect} / {dataset_name} / {model_name}")
    inv_result = invariant_enforcing_eval(
        model=model, tokenizer=tokenizer,
        test_set=test_set,
        taxonomy=taxonomy,
        normalizer=normalizer,
        lookup_table=lookup_table,
        batch_size=batch_size,
        max_new_tokens=max_new_tokens,
        dataset_name=dataset_name,
    )

    corrected_acc = inv_result["accuracy_with_bot_as_error"]
    bot_rate = inv_result["bot_rate"]
    # Δ = defective_acc - corrected_acc (in percentage points).
    # Mathematically equivalent to Equation 2 r*(a_k - a_d) when a_d=0
    # (unmatched rows are never correct by construction in this framework).
    delta = (defective_acc - corrected_acc) * 100

    return {
        "dataset": dataset_name,
        "defect": defect,
        "model": model_name,
        "defective_acc": round(defective_acc * 100, 1),
        "corrected_acc": round(corrected_acc * 100, 1),
        "bot_rate": round(bot_rate * 100, 1),
        "invariant_fired": _invariant_fired_for_defect(defect),
        "delta_pts": round(delta, 1),
    }


def write_table5(rows: List[Dict]) -> None:
    with open(TABLE5_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=TABLE5_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"Table 5 written to {TABLE5_PATH} ({len(rows)} rows)")


def write_table3(rows: List[Dict]) -> None:
    from collections import defaultdict
    defect_stats = defaultdict(lambda: {"max_delta": 0.0, "max_bot_rate": 0.0})
    for row in rows:
        d = row["defect"]
        defect_stats[d]["max_delta"] = max(defect_stats[d]["max_delta"], row["delta_pts"])
        defect_stats[d]["max_bot_rate"] = max(defect_stats[d]["max_bot_rate"], row["bot_rate"])

    summary_rows = [
        {
            "defect": defect,
            "invariant_fired": _invariant_fired_for_defect(defect),
            "max_delta_pts": stats["max_delta"],
            "max_bot_rate_pct": stats["max_bot_rate"],
        }
        for defect, stats in sorted(defect_stats.items())
    ]

    with open(TABLE3_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["defect", "invariant_fired", "max_delta_pts", "max_bot_rate_pct"])
        writer.writeheader()
        writer.writerows(summary_rows)
    logger.info(f"Table 3 written to {TABLE3_PATH}")


def main(dry_run: bool = False) -> None:
    config = load_config()

    model_names = [m["name"] for m in config["models"]]
    dataset_names = list(config["datasets"].keys())
    defects = ["D1", "D2", "D3", "D4"]

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = LOGS_DIR / f"injection_run_{timestamp}.log"
    file_handler = logging.FileHandler(log_path)
    file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
    logging.getLogger().addHandler(file_handler)

    all_rows: List[Dict] = []

    if dry_run:
        logger.info("DRY RUN MODE — no GPU inference, synthetic numbers only")
        for model_name in model_names:
            for dataset_name in dataset_names:
                for defect in defects:
                    row = run_cell_dry(model_name, dataset_name, defect, config)
                    all_rows.append(row)
                    logger.info(f"  [{defect}/{dataset_name}/{model_name}] {row}")
    else:
        from models.loader import load_model  # type: ignore
        from data.loaders import get_dataset  # type: ignore

        for model_name in model_names:
            logger.info(f"Loading model: {model_name}")
            model, tokenizer = load_model(model_name, quantize=True)

            for dataset_name in dataset_names:
                logger.info(f"Loading dataset: {dataset_name}")
                test_set = get_dataset(dataset_name)

                for defect in defects:
                    logger.info(f"=== Cell: {defect} / {dataset_name} / {model_name} ===")
                    t0 = time.time()
                    row = run_cell(model, tokenizer, model_name, test_set, dataset_name, defect, config)
                    elapsed = time.time() - t0
                    all_rows.append(row)
                    logger.info(f"  Done in {elapsed:.0f}s: {row}")

            # Free GPU memory between models
            del model, tokenizer
            try:
                import torch
                torch.cuda.empty_cache()
            except Exception:
                pass

    assert len(all_rows) == 24, f"Expected 24 cells, got {len(all_rows)}"
    write_table5(all_rows)
    write_table3(all_rows)
    logger.info("Injection matrix complete.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run the 24-cell injection matrix study.")
    parser.add_argument("--dry-run", action="store_true", help="Synthetic run without GPU")
    args = parser.parse_args()
    main(dry_run=args.dry_run)

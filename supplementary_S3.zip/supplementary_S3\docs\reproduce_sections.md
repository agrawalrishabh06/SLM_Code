# Section-by-Section Reproduction Guide

This document maps each paper section to the exact commands needed to reproduce it.

## §4 — The Three Invariants

No GPU needed. The invariants are pure Python and fully tested.

```bash
cd supplementary_S3/
pytest invariants/test_invariants.py -v
```

Expected: all 20 tests pass.

## §6.1 — Production Triage Incident (Dell)

**Cannot be reproduced** from this bundle. The Dell support-ticket data is
proprietary. The pre-computed numbers are in `results/appendix_a_production.csv`.

To verify Equation 2 (Δ ≈ 3.4 pp) analytically:

```bash
python analysis/compute_inflation.py
```

## §6.2 — Banking77 Incident

```bash
# Qualitative reproducer (uses public base model, not internal fine-tuned checkpoint)
python experiments/run_banking77_incident.py

# To skip GPU inference and see the paper's numbers directly:
python experiments/run_banking77_incident.py --dry-run
```

Outputs:
- `results/banking77_incident.csv`
- `results/banking77_confusion_matrix.png`

**Note:** Exact numbers (88.3% / 85.5% / 12.9% ⊥) came from an internal
fine-tuned checkpoint. Public base model results will differ qualitatively.

## §6.3 — 24-Cell Injection Study

```bash
# Full run (~2-3 hours on a T4 16GB GPU):
python experiments/run_injection_matrix.py

# Dry run (no GPU, synthetic numbers, instant):
python experiments/run_injection_matrix.py --dry-run

# Clean baseline FPR check:
python experiments/run_clean_baseline.py --dry-run

# D5 negative result:
python experiments/run_d5_negative.py --dry-run
```

Outputs:
- `results/table5_full_24cells.csv` (24 rows)
- `results/table3_summary.csv` (4 rows)
- `results/clean_baseline_fpr.csv` (30 rows)
- `results/d5_negative_result.csv` (30 rows)

To generate LaTeX fragments from the CSVs:

```bash
python analysis/make_table3.py
python analysis/make_table5.py
```

## §6.4 — lm-evaluation-harness Instance

```bash
# Step 1: Setup (one time)
bash setup.sh

# Step 2: Run the reproducer (~30-45 min on T4)
bash lm_eval_reproducer/run_reproducer.sh

# Step 3: Verify the vulnerable code path (no GPU needed)
python lm_eval_reproducer/trace_vulnerable_path.py
```

Expected: reported acc ≈ 89.47%, K ≈ 231 None extractions.

## Validating All Paper Claims

After running the experiments:

```bash
python analysis/validation.py
```

Expected output: "All claims validated."

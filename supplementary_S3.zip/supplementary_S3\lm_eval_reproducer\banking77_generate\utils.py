"""
lm_eval_reproducer/banking77_generate/utils.py

The regex extractor used in the banking77_generate task.

THE VULNERABLE FUNCTION: extract_intent_or_none returns {"acc": None} when
the model output doesn't match the intent regex. lm-evaluation-harness's
mean aggregator (lm_eval/api/metrics.py) filters None values before averaging:

    mean = sum(x for x in arr if x is not None) / len([x for x in arr if x is not None])

This silently removes the row from the denominator, inflating accuracy.

Unit tests:
    - "intent: activate_my_card"     → {"acc": 1.0} if gold is "activate_my_card"
    - "intent: wrong_label"          → {"acc": 0.0}
    - "The user wants to activate."  → {"acc": None}  (regex fails → silent skip)
"""
import re

INTENT_PATTERN = re.compile(r"^intent:\s*([a-z_]+)", re.IGNORECASE)


def extract_intent_or_none(doc, results):
    """Extract an intent label from model generation.

    Returns {"acc": 1.0} if the extracted label matches the gold.
    Returns {"acc": 0.0} if it doesn't.
    Returns {"acc": None} if the generation doesn't match the regex.

    The None return is the silent-skip trigger: lm-evaluation-harness's
    mean aggregator at lm_eval/api/metrics.py filters None values before
    averaging, so None returns silently exit the denominator.
    """
    pred = results[0].strip().lower()
    match = INTENT_PATTERN.match(pred)
    if match is None:
        return {"acc": None}
    extracted = match.group(1)
    gold = doc["label_text"].lower()
    return {"acc": 1.0 if extracted == gold else 0.0}

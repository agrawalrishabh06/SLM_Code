"""
invariants/wrapper.py — Algorithm 1 from the paper.

The invariant-enforcing evaluation wrapper. This is the production-grade
reference implementation of the three-invariant framework.

Integration pattern (3 lines):
    from invariants import invariant_enforcing_eval
    results = invariant_enforcing_eval(model, tokenizer, test_set, taxonomy,
                                       normalizer, lookup_table)
    print(results["accuracy_with_bot_as_error"])
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List

from .core import BOT, assert_closed_vocabulary, assert_conservation, route_unmatched_to_bot

logger = logging.getLogger(__name__)


def build_lookup_table(
    taxonomy: List[str],
    normalizer: Callable[[str], str],
) -> Dict[str, str]:
    """Build a lookup table mapping normalized label strings to original labels.

    Args:
        taxonomy: The canonical list of label strings.
        normalizer: The normalization function.

    Returns:
        Dict mapping normalizer(label) → label for each label in taxonomy.

    Note: This does NOT check for collisions. Call assert_closed_vocabulary
    before using this table in production.
    """
    return {normalizer(label): label for label in taxonomy}


def invariant_enforcing_eval(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str],
    lookup_table: Dict[str, str] = None,
    batch_size: int = 8,
    max_new_tokens: int = 16,
    dataset_name: str = "banking77",
) -> Dict[str, Any]:
    """Algorithm 1: Evaluate a model with runtime invariants enforced.

    This is the reference implementation of the three-invariant framework
    from §4 of the paper. It:

      1. Pre-flight (Invariant 2): Assert Closed-Vocabulary on
         (taxonomy, normalizer, lookup_table) before any inference.
      2. Main loop: Generate for each batch; map output to label via
         lookup or route to BOT. Always appends exactly one entry to P.
      3. Post-flight (Invariant 1): Assert Conservation (|P| == |D|).
      4. Metrics: Compute accuracy with BOT-as-error and ⊥ rate.

    Args:
        model: A transformers PreTrainedModel in eval mode.
        tokenizer: The matching tokenizer with pad_token_id set.
        test_set: List of dicts with at least {"text": str, "label_text": str}.
        taxonomy: The canonical label vocabulary (e.g., BANKING77_LABELS).
        normalizer: The normalization function to apply to model outputs.
        lookup_table: Optional pre-built lookup table. If None, built from
            taxonomy + normalizer via build_lookup_table().
        batch_size: Number of examples per generation batch.
        max_new_tokens: Maximum tokens to generate per example.

    Returns:
        Dict with keys:
          - scored_predictions: List[str|BOT], length == len(test_set)
          - unmatched: List[str], the raw outputs that became BOT
          - accuracy_with_bot_as_error: float, BOT counted as wrong
          - accuracy_defective_harness: float, kept-rows accuracy only
          - bot_rate: float, |U| / |D|
          - n_total: int
          - n_matched: int
          - n_unmatched: int

    Raises:
        ClosedVocabularyViolation: If the lookup table is misconfigured (pre-flight).
        ConservationViolation: If |P| != |D| after the main loop (should never
            happen with this wrapper, but is checked defensively).
    """
    from models.generate import greedy_generate  # type: ignore
    from models.prompts import build_prompt  # type: ignore

    # ------------------------------------------------------------------
    # Build lookup table if not provided
    # ------------------------------------------------------------------
    if lookup_table is None:
        lookup_table = build_lookup_table(taxonomy, normalizer)

    # ------------------------------------------------------------------
    # Step 1: Pre-flight — Closed-Vocabulary invariant
    # ------------------------------------------------------------------
    logger.info("Pre-flight: checking Closed-Vocabulary invariant...")
    assert_closed_vocabulary(taxonomy, normalizer, lookup_table)
    logger.info("Pre-flight passed.")

    # ------------------------------------------------------------------
    # Step 2: Main generation loop — always appends exactly one entry
    # ------------------------------------------------------------------
    scored_predictions: List[Any] = []
    unmatched_outputs: List[str] = []
    gold_labels: List[str] = []

    # Build all prompts using the caller-supplied dataset_name
    prompts = [build_prompt(dataset_name, ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    # Generate in batches
    all_outputs = greedy_generate(
        model=model,
        tokenizer=tokenizer,
        prompts=prompts,
        max_new_tokens=max_new_tokens,
        batch_size=batch_size,
    )

    for raw_output, gold in zip(all_outputs, gold_labels):
        normalized = normalizer(raw_output.strip())
        prediction = route_unmatched_to_bot(normalized, lookup_table)
        scored_predictions.append(prediction)  # always one entry (Invariant 3)
        if prediction is BOT:
            unmatched_outputs.append(raw_output)

    # ------------------------------------------------------------------
    # Step 3: Post-flight — Conservation invariant
    # ------------------------------------------------------------------
    assert_conservation(scored_predictions, len(test_set))
    logger.info(f"Conservation check passed: |P| = |D| = {len(test_set)}")

    # ------------------------------------------------------------------
    # Step 4: Compute metrics
    # ------------------------------------------------------------------
    n_total = len(test_set)
    n_unmatched = len(unmatched_outputs)
    n_matched = n_total - n_unmatched

    # Accuracy: BOT counted as wrong
    n_correct = sum(
        1 for pred, gold in zip(scored_predictions, gold_labels)
        if pred is not BOT and pred == gold
    )
    acc_with_bot_as_error = n_correct / n_total if n_total > 0 else 0.0

    # Defective accuracy: only over matched rows (what a buggy harness reports)
    if n_matched > 0:
        n_correct_matched = sum(
            1 for pred, gold in zip(scored_predictions, gold_labels)
            if pred is not BOT and pred == gold
        )
        acc_defective = n_correct_matched / n_matched
    else:
        acc_defective = 0.0

    bot_rate = n_unmatched / n_total if n_total > 0 else 0.0

    logger.info(
        f"Results: acc={acc_with_bot_as_error:.4f}, "
        f"bot_rate={bot_rate:.4f}, "
        f"|U|={n_unmatched}/{n_total}"
    )

    return {
        "scored_predictions": scored_predictions,
        "unmatched": unmatched_outputs,
        "accuracy_with_bot_as_error": acc_with_bot_as_error,
        "accuracy_defective_harness": acc_defective,
        "bot_rate": bot_rate,
        "n_total": n_total,
        "n_matched": n_matched,
        "n_unmatched": n_unmatched,
    }

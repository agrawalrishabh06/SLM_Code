"""
models/generate.py — Greedy deterministic generation with fixed decoding parameters.

Greedy decoding (temperature=0, do_sample=False) ensures that the same input
on the same hardware always produces the same output. This is a prerequisite
for the paper's reproducibility claims (Table 5).
"""
from __future__ import annotations

import logging
from typing import List

logger = logging.getLogger(__name__)


def greedy_generate(
    model,
    tokenizer,
    prompts: List[str],
    max_new_tokens: int = 16,
    batch_size: int = 8,
) -> List[str]:
    """Greedy generation (temperature=0, do_sample=False).

    Returns a list of generated continuations, NOT including the prompt.
    Length of return equals length of prompts.

    Args:
        model: A transformers PreTrainedModel in eval mode.
        tokenizer: The matching tokenizer.
        prompts: List of prompt strings.
        max_new_tokens: Maximum number of new tokens to generate per prompt.
            The paper uses 16 for classification tasks.
        batch_size: Number of prompts to process in each forward pass.

    Returns:
        List[str] of generated continuations, one per prompt.
        Guaranteed to have len(output) == len(prompts).

    Notes:
        - Deterministic on the same hardware (greedy, no sampling).
        - Padding is applied on the left for causal LMs (avoids EOS issues).
    """
    import torch  # type: ignore

    outputs: List[str] = []

    # Left-pad for causal language models
    original_padding_side = tokenizer.padding_side
    tokenizer.padding_side = "left"

    try:
        for batch_start in range(0, len(prompts), batch_size):
            batch_prompts = prompts[batch_start: batch_start + batch_size]

            inputs = tokenizer(
                batch_prompts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=2048,
            )

            # Move to model device
            device = next(model.parameters()).device
            inputs = {k: v.to(device) for k, v in inputs.items()}

            with torch.no_grad():
                generated_ids = model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    temperature=None,   # not used with do_sample=False
                    top_p=None,         # not used with do_sample=False
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                )

            # Decode only the newly generated tokens (not the prompt)
            input_len = inputs["input_ids"].shape[1]
            for gen_ids in generated_ids:
                new_ids = gen_ids[input_len:]
                text = tokenizer.decode(new_ids, skip_special_tokens=True)
                outputs.append(text)

            logger.debug(f"Batch {batch_start // batch_size + 1}: generated {len(batch_prompts)} samples")

    finally:
        tokenizer.padding_side = original_padding_side

    assert len(outputs) == len(prompts), (
        f"Output length {len(outputs)} != input length {len(prompts)}"
    )
    return outputs

"""
experiments/run_d5_negative.py — D5 negative-result experiment (§6.5).

Shows that accuracy fluctuates by up to ~4.1 points due to prompt-order
permutation, but NO invariant fires. This is the paper's honesty move:
explicit evidence of what the invariants miss.

Loops over:
  - 3 models × 2 datasets × 5 permutation seeds = 30 runs

Writes:
  - results/d5_negative_result.csv (30 rows)

Usage:
    python experiments/run_d5_negative.py
    python experiments/run_d5_negative.py --dry-run
"""
from __future__ import annotations

import argparse
import csv
import logging
import random
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

RESULTS_DIR = ROOT / "results"
RESULTS_DIR.mkdir(exist_ok=True)
D5_PATH = RESULTS_DIR / "d5_negative_result.csv"

D5_FIELDS = [
    "model", "dataset", "permutation_seed",
    "accuracy", "conservation_fired", "closed_vocab_fired", "bot_rate",
]

CONFIG_PATH = Path(__file__).parent / "experiment_config.yaml"


def load_config():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)


def run_d5_cell_dry(model_name, dataset_name, seed):
    rng = random.Random(seed + hash(model_name + dataset_name) % 1000)
    acc = rng.uniform(0.83, 0.89)
    bot_rate = rng.uniform(0.002, 0.006)
    return {
        "model": model_name,
        "dataset": dataset_name,
        "permutation_seed": seed,
        "accuracy": round(acc * 100, 1),
        "conservation_fired": False,
        "closed_vocab_fired": False,
        "bot_rate": round(bot_rate * 100, 3),
    }


def run_d5_cell(model, tokenizer, model_name, dataset_name, perm_seed, config):
    from data.loaders import get_dataset  # type: ignore
    from data.taxonomies import get_taxonomy  # type: ignore
    from data.normalizers import norm_strip_lower  # type: ignore
    from invariants.wrapper import build_lookup_table  # type: ignore
    from defects.d5_permutation import defective_pipeline_d5  # type: ignore

    test_set = get_dataset(dataset_name)
    taxonomy = get_taxonomy(dataset_name)
    normalizer = norm_strip_lower
    lookup_table = build_lookup_table(taxonomy, normalizer)

    dcfg = config.get("generation", {})
    result = defective_pipeline_d5(
        model=model,
        tokenizer=tokenizer,
        test_set=test_set,
        taxonomy=taxonomy,
        normalizer=normalizer,
        lookup_table=lookup_table,
        permutation_seed=perm_seed,
        batch_size=dcfg.get("batch_size", 8),
        max_new_tokens=dcfg.get("max_new_tokens", 16),
    )

    return {
        "model": model_name,
        "dataset": dataset_name,
        "permutation_seed": perm_seed,
        "accuracy": round(result["accuracy"] * 100, 1),
        "conservation_fired": result["conservation_fired"],
        "closed_vocab_fired": result["closed_vocab_fired"],
        "bot_rate": round(result["bot_rate"] * 100, 3),
    }


def main(dry_run=False):
    config = load_config()
    model_names = [m["name"] for m in config["models"]]
    dataset_names = list(config["datasets"].keys())
    seeds = config["seeds"]["d5_permutation"]

    all_rows = []

    if dry_run:
        logger.info("DRY RUN MODE")
        for model_name in model_names:
            for dataset_name in dataset_names:
                for seed in seeds:
                    row = run_d5_cell_dry(model_name, dataset_name, seed)
                    all_rows.append(row)
    else:
        from models.loader import load_model  # type: ignore

        for model_name in model_names:
            model, tokenizer = load_model(model_name)
            for dataset_name in dataset_names:
                for seed in seeds:
                    logger.info(f"D5 run: {model_name}/{dataset_name}/seed={seed}")
                    row = run_d5_cell(model, tokenizer, model_name, dataset_name, seed, config)
                    all_rows.append(row)
                    logger.info(f"  {row}")
            del model, tokenizer
            try:
                import torch; torch.cuda.empty_cache()
            except Exception:
                pass

    assert len(all_rows) == 30, f"Expected 30 rows, got {len(all_rows)}"

    # Validate: no invariant should have fired
    any_conservation = any(r["conservation_fired"] for r in all_rows)
    any_closed_vocab = any(r["closed_vocab_fired"] for r in all_rows)
    if any_conservation:
        logger.error("Conservation fired in D5 run — should never happen!")
    if any_closed_vocab:
        logger.error("Closed-Vocabulary fired in D5 run — should never happen!")

    # Compute per-cell accuracy range
    from collections import defaultdict
    cell_accs = defaultdict(list)
    for r in all_rows:
        key = (r["model"], r["dataset"])
        cell_accs[key].append(r["accuracy"])

    max_range = 0.0
    for key, accs in cell_accs.items():
        rng = max(accs) - min(accs)
        max_range = max(max_range, rng)
        logger.info(f"  {key}: acc range = {rng:.1f} pts (min={min(accs):.1f}, max={max(accs):.1f})")

    logger.info(f"Max per-cell accuracy range: {max_range:.1f} pts (paper claims up to 4.1)")

    with open(D5_PATH, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=D5_FIELDS)
        writer.writeheader()
        writer.writerows(all_rows)

    logger.info(f"D5 results written to {D5_PATH}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    main(dry_run=args.dry_run)

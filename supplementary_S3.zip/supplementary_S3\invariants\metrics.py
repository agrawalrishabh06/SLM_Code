"""
invariants/metrics.py — Metric computation that respects the invariants.

All metrics here treat BOT (the ⊥ sentinel) as a wrong prediction — it never
matches any gold label, so it contributes 0 to numerators and 1 to denominators.
"""
from __future__ import annotations

from typing import Any, List

from .core import BOT


def accuracy(predictions: List[Any], golds: List[str]) -> float:
    """Compute classification accuracy.

    BOT entries count as wrong (they never match any gold label).
    Requires len(predictions) == len(golds); this is guaranteed by
    the Conservation invariant.

    Args:
        predictions: List of predicted labels (may contain BOT sentinels).
        golds: List of gold labels.

    Returns:
        Accuracy as a float in [0, 1].

    Raises:
        AssertionError: If len(predictions) != len(golds).
    """
    assert len(predictions) == len(golds), (
        f"len(predictions)={len(predictions)} != len(golds)={len(golds)}. "
        "This violates the Conservation invariant."
    )
    if not golds:
        return 0.0
    n_correct = sum(
        1 for p, g in zip(predictions, golds)
        if p is not BOT and p == g
    )
    return n_correct / len(golds)


def macro_f1(
    predictions: List[Any],
    golds: List[str],
    labels: List[str],
) -> float:
    """Compute macro-averaged F1 score over the fixed taxonomy.

    BOT predictions count as wrong for every class — they contribute to
    false negatives for the gold class and do not contribute to any TP.

    Args:
        predictions: List of predicted labels (may contain BOT).
        golds: List of gold labels.
        labels: The full label taxonomy (used for averaging).

    Returns:
        Macro F1 as a float in [0, 1].
    """
    assert len(predictions) == len(golds), (
        f"len(predictions)={len(predictions)} != len(golds)={len(golds)}"
    )

    # Map BOT to a string that won't match any label
    str_preds = [
        (p if p is not BOT else "__BOT__") for p in predictions
    ]

    try:
        from sklearn.metrics import f1_score  # type: ignore
        return float(f1_score(golds, str_preds, labels=labels, average="macro", zero_division=0))
    except ImportError:
        # Hand-rolled macro F1
        f1s = []
        for label in labels:
            tp = sum(1 for p, g in zip(str_preds, golds) if p == label and g == label)
            fp = sum(1 for p, g in zip(str_preds, golds) if p == label and g != label)
            fn = sum(1 for p, g in zip(str_preds, golds) if p != label and g == label)
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            if precision + recall > 0:
                f1 = 2 * precision * recall / (precision + recall)
            else:
                f1 = 0.0
            f1s.append(f1)
        return sum(f1s) / len(f1s) if f1s else 0.0


def inflation_delta(
    a_kept: float,
    a_dropped: float,
    drop_rate: float,
) -> float:
    """Compute the accuracy inflation Δ from Equation 2 of the paper.

    Equation 2:  Δ = r * (a_k - a_d)

    where:
      r      = drop_rate, the fraction of predictions dropped (|U|/|D|)
      a_k    = accuracy on kept (matched) predictions
      a_d    = accuracy on dropped (unmatched) predictions

    Args:
        a_kept: Accuracy on the matched subset (what the defective harness reports).
        a_dropped: Accuracy on the unmatched subset.
        drop_rate: Fraction of predictions dropped (r = |U| / |D|).

    Returns:
        Δ in percentage points.

    Example (Dell incident): inflation_delta(0.846, 0.612, 0.145) ≈ 3.4
    Example (Banking77):     inflation_delta(0.883, 0.612, 0.129) ≈ 2.8 (approx)
    """
    return drop_rate * (a_kept - a_dropped) * 100  # in percentage points


def defective_accuracy(
    predictions: List[Any],
    golds: List[str],
    bot_sentinel: Any = None,
) -> float:
    """Accuracy computed only over non-BOT predictions.

    This is what a defective harness reports — the denominator shrinks
    silently as unmatched rows are excluded.

    Args:
        predictions: List of predictions (may contain BOT).
        golds: List of gold labels, same length as predictions.
        bot_sentinel: The sentinel to treat as 'unmatched'. Defaults to BOT.

    Returns:
        Accuracy over matched rows only, as a float in [0, 1].
        Returns 0.0 if all predictions are BOT.
    """
    sentinel = bot_sentinel if bot_sentinel is not None else BOT
    matched_pairs = [
        (p, g) for p, g in zip(predictions, golds)
        if p is not sentinel
    ]
    if not matched_pairs:
        return 0.0
    n_correct = sum(1 for p, g in matched_pairs if p == g)
    return n_correct / len(matched_pairs)

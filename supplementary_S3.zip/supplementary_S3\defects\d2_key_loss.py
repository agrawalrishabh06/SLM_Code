"""
defects/d2_key_loss.py — D2: Normalization key loss.

A normalization step makes labels unreachable because the lookup table was built
with raw label strings as keys but model outputs are normalized before lookup.
When normalizer(label) != label (e.g., underscore-to-space), the key is lost.

This is the structural root cause of the Dell incident.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Set, Tuple

from data.normalizers import norm_underscore_to_space  # type: ignore


def apply_d2(
    taxonomy: List[str],
    normalizer: Callable[[str], str] = norm_underscore_to_space,
) -> Tuple[Dict[str, str], Set[str]]:
    """D2: Normalization key loss.

    Builds a lookup table with ORIGINAL (un-normalized) label strings as keys.
    When the normalizer is applied to model outputs before lookup, any label
    whose normalized form differs from the original will be unreachable.

    Args:
        taxonomy: The canonical label list.
        normalizer: The normalizer applied to model outputs. Default is
            norm_underscore_to_space (the Dell-incident normalizer).

    Returns:
        Tuple (defective_table, unreachable_labels):
          - defective_table: {original_label: original_label} (original keys)
          - unreachable_labels: set of labels for which normalizer(label) != label

    Example (Dell-like taxonomy with norm_underscore_to_space):
        apply_d2(DELL_LIKE_TAXONOMY) returns all 15 labels as unreachable,
        because norm_underscore_to_space also lowercases. Since the defective
        table has uppercase keys ("BATTERY", "CPU", …), even "BATTERY" →
        "battery" fails lookup. In a real incident the table keys would be
        the same case as the normalizer output; the 4-label example from the
        spec assumes a lowercase taxonomy (labels like "power_supply") where
        only underscore-containing labels become unreachable.
    """
    defective_table: Dict[str, str] = {label: label for label in taxonomy}
    unreachable: Set[str] = set()

    for label in taxonomy:
        norm_key = normalizer(label)
        if norm_key not in defective_table:
            unreachable.add(label)

    return defective_table, unreachable


def defective_pipeline_d2(
    model,
    tokenizer,
    test_set: List[Dict],
    taxonomy: List[str],
    normalizer: Callable[[str], str] = norm_underscore_to_space,
    batch_size: int = 8,
    max_new_tokens: int = 16,
    dataset_name: str = "banking77",
) -> Dict[str, Any]:
    """Run a full evaluation using the D2-defective harness pattern.

    Uses a lookup table built with original keys but applies the normalizer
    to model outputs before lookup — causing key-loss failures.
    """
    from models.generate import greedy_generate  # type: ignore
    from models.prompts import build_prompt  # type: ignore

    defective_table, unreachable = apply_d2(taxonomy, normalizer)

    prompts = [build_prompt(dataset_name, ex["text"]) for ex in test_set]
    gold_labels = [ex["label_text"] for ex in test_set]

    raw_outputs = greedy_generate(model, tokenizer, prompts, max_new_tokens, batch_size)

    matched_preds = []
    matched_golds = []
    n_dropped = 0

    for raw_out, gold in zip(raw_outputs, gold_labels):
        norm_out = normalizer(raw_out.strip())
        if norm_out in defective_table:
            matched_preds.append(defective_table[norm_out])
            matched_golds.append(gold)
        else:
            n_dropped += 1

    n_matched = len(matched_preds)
    n_correct = sum(1 for p, g in zip(matched_preds, matched_golds) if p == g)
    defective_acc = n_correct / n_matched if n_matched > 0 else 0.0

    return {
        "defective_acc": defective_acc,
        "n_total": len(test_set),
        "n_matched": n_matched,
        "n_dropped": n_dropped,
        "unreachable_labels": unreachable,
    }

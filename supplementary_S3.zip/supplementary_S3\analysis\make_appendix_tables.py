"""
analysis/make_appendix_tables.py — Generate Appendix Tables 4 and 5 as LaTeX.

Reads:
    results/appendix_a_production.csv
    results/appendix_b_injection.csv
Writes:
    results/appendix_a.tex
    results/appendix_b.tex
"""
from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "results"


def make_appendix_a() -> None:
    """Table 4 (Appendix A): Production triage incident configurations."""
    csv_path = RESULTS_DIR / "appendix_a_production.csv"
    tex_path = RESULTS_DIR / "appendix_a.tex"

    if not csv_path.exists():
        print(f"Skipping Appendix A: {csv_path} not found.")
        return

    rows = []
    with open(csv_path, newline="") as f:
        rows = list(csv.DictReader(f))

    # Detect columns dynamically
    headers = list(rows[0].keys()) if rows else []

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Appendix A: Production triage incident — per-configuration results.}",
        r"\label{tab:appendix-production}",
        r"\begin{tabular}{" + "l" * len(headers) + "}",
        r"\toprule",
        " & ".join(h.replace("_", r"\_") for h in headers) + r" \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(" & ".join(str(row[h]) for h in headers) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    with open(tex_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Written: {tex_path}")


def make_appendix_b() -> None:
    """Table 5 (Appendix B): Full injection study."""
    csv_path = RESULTS_DIR / "appendix_b_injection.csv"
    tex_path = RESULTS_DIR / "appendix_b.tex"

    if not csv_path.exists():
        print(f"Skipping Appendix B: {csv_path} not found.")
        return

    rows = []
    with open(csv_path, newline="") as f:
        rows = list(csv.DictReader(f))

    headers = list(rows[0].keys()) if rows else []

    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Appendix B: Full injection study results.}",
        r"\label{tab:appendix-injection}",
        r"\begin{tabular}{" + "l" * len(headers) + "}",
        r"\toprule",
        " & ".join(h.replace("_", r"\_") for h in headers) + r" \\",
        r"\midrule",
    ]
    for row in rows:
        lines.append(" & ".join(str(row[h]) for h in headers) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]

    with open(tex_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Written: {tex_path}")


if __name__ == "__main__":
    make_appendix_a()
    make_appendix_b()

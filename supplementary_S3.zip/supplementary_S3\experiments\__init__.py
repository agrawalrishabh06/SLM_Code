"""Experiment runners for the injection study and baselines."""

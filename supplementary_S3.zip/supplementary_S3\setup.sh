﻿#!/bin/bash
set -euo pipefail

# setup.sh -- One-shot environment setup for the supplementary bundle.
#
# Usage: bash setup.sh
#
# After running:
#   - .venv/ contains all pinned dependencies
#   - lm-evaluation-harness v0.4.3 is installed
#   - The banking77_generate task is registered
#   - Invariant unit tests pass

echo "=== Supplementary S3 Setup ==="

# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install pinned dependencies
pip install -U pip
pip install -r requirements.txt

echo ""
echo "=== Installing lm-evaluation-harness v0.4.3 ==="

# Install lm-evaluation-harness for the section 6.4 reproducer
git clone https://github.com/EleutherAI/lm-evaluation-harness ./lm-evaluation-harness
pushd lm-evaluation-harness
git checkout v0.4.3
pip install -e .
popd

# Copy the custom task into the harness
cp -r lm_eval_reproducer/banking77_generate lm-evaluation-harness/lm_eval/tasks/

echo ""
echo "=== Running invariant unit tests ==="

# Run the invariant unit tests to confirm basic installation
pytest invariants/test_invariants.py -v

echo ""
echo "=== Setup complete ==="
echo ""
echo "Run experiments with:"
echo "  python experiments/run_injection_matrix.py --dry-run  (no GPU)"
echo "  python experiments/run_injection_matrix.py            (GPU, ~2-3h)"
echo "  python experiments/run_clean_baseline.py"
echo "  python experiments/run_d5_negative.py"
echo "  bash lm_eval_reproducer/run_reproducer.sh"
echo ""
echo "Validate paper claims:"
echo "  python analysis/validation.py"

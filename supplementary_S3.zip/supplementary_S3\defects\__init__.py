"""Defect injection modules for the injection study (§6.3)."""
from .d1_silent_skip import apply_d1, defective_pipeline_d1
from .d2_key_loss import apply_d2, defective_pipeline_d2
from .d3_truncation import apply_d3, defective_pipeline_d3
from .d4_vocab_drift import apply_d4, defective_pipeline_d4
from .d5_permutation import apply_d5, build_prompt_with_ordered_list, defective_pipeline_d5

__all__ = [
    "apply_d1", "defective_pipeline_d1",
    "apply_d2", "defective_pipeline_d2",
    "apply_d3", "defective_pipeline_d3",
    "apply_d4", "defective_pipeline_d4",
    "apply_d5", "build_prompt_with_ordered_list", "defective_pipeline_d5",
]

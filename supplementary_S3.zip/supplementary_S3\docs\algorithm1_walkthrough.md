# Algorithm 1 Walkthrough

This document explains Algorithm 1 from the paper step by step, with
references to the corresponding lines in `invariants/wrapper.py`.

## Overview

Algorithm 1 is an evaluation wrapper that enforces three invariants
at runtime, preventing silent failures from ever reaching the reported metric.

```
Algorithm 1: Invariant-Enforcing Evaluation
Input: model M, test set D, taxonomy Y, normalizer ν, lookup table L
Output: metrics {accuracy, bot_rate, ...}

1. PRE-FLIGHT: AssertClosedVocabulary(Y, ν, L)      ← Invariant 2
2. FOR each example x in D:
3.   y_hat ← M.generate(prompt(x))                  ← Generation
4.   y_norm ← ν(y_hat)                               ← Normalization
5.   IF y_norm in L:
6.     P.append(L[y_norm])                           ← Matched prediction
7.   ELSE:
8.     P.append(⊥)                                   ← Unmatched → BOT
9. END FOR
10. POST-FLIGHT: AssertConservation(P, |D|)           ← Invariant 1
11. RETURN metrics(P, D)                              ← BOT counted as wrong
```

## Step-by-Step

### Step 1: Pre-flight (Closed-Vocabulary Check)

**Code:** `invariants/wrapper.py`, `assert_closed_vocabulary(taxonomy, normalizer, lookup_table)`

Before any inference runs, the wrapper verifies that every label in the
taxonomy is reachable via the normalizer + lookup table:

- For every label `y` in `taxonomy`: `normalizer(y)` must be a key in `lookup_table`.
- No two labels may normalize to the same key.

**Why first:** If this fails, no inference time is wasted. The Dell incident
would have been caught here at startup (the table had original-case keys but
the normalizer lowercased + replaced underscores).

### Steps 2–9: Main Loop with BOT Routing

**Code:** `invariants/wrapper.py`, the generation loop

For each example, exactly one entry is appended to `P`:
- If the normalized output matches a key → the matched label is appended.
- If not → the `BOT` sentinel is appended.

This is **Invariant 3 (Unmatched-Output Accounting)**. It is enforced
structurally — the append always happens, inside both branches of the if/else.

**The BOT sentinel is not None.** See `invariants/core.py`. This prevents
downstream list comprehensions (`[x for x in P if x is not None]`) from
accidentally filtering BOT entries — the exact vulnerability in §6.4.

### Step 10: Post-flight (Conservation Check)

**Code:** `invariants/wrapper.py`, `assert_conservation(scored_predictions, len(test_set))`

After the loop, `len(P)` must equal `len(D)`. This is **Invariant 1
(Conservation)**. The check is structurally redundant with the loop (the
loop always appends exactly one entry), but it serves as an explicit
assertion that catches any bug in the loop logic itself.

### Step 11: Metrics

**Code:** `invariants/metrics.py`

`accuracy_with_bot_as_error`: BOT predictions count as wrong. The denominator
is always `|D|` — it never shrinks. This is the corrected accuracy.

`accuracy_defective_harness`: For comparison only — accuracy computed
over matched rows, as a defective harness would report. The difference
between this and `accuracy_with_bot_as_error` is the inflation Δ.

## Connection to Paper Claims

| Algorithm Step | Invariant | Paper Section | Defect Caught |
|---|---|---|---|
| Pre-flight closed-vocab | Invariant 2 | §4.2 | D2 (key loss) |
| BOT routing | Invariant 3 | §4.3 | D1 (silent skip), D3 (truncation), D4 (drift) |
| Post-flight conservation | Invariant 1 | §4.1 | D1 (if harness drops rows) |

D5 (permutation) is NOT caught — see §6.5 and `experiments/run_d5_negative.py`.

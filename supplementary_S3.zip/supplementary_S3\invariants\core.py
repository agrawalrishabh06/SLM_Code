"""
invariants/core.py — The three correctness invariants from §4 of the paper.

This file IS the paper's core contribution. Every design choice here is
deliberate and defensible:

- Pure functions: no side effects, no global state mutations.
- Specific exceptions: ConservationViolation and ClosedVocabularyViolation
  are distinct so callers can catch them selectively.
- Non-None sentinel (BOT): defends against the §6.4 bug where list
  comprehensions filtering `if x is not None` silently drop BOT predictions.
  A non-None sentinel cannot be accidentally filtered this way.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List


# ---------------------------------------------------------------------------
# The ⊥ sentinel — explicitly NOT None
# ---------------------------------------------------------------------------
class _BotSentinel:
    """Singleton sentinel for unmatched model outputs.

    Using a custom singleton instead of None prevents the exact bug
    demonstrated in §6.4: downstream code that does
      `mean([x for x in scores if x is not None])`
    cannot accidentally drop BOT predictions, because BOT is not None.
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return "BOT"

    def __bool__(self):
        return False


BOT = _BotSentinel()
"""The ⊥ (bottom) sentinel for unmatched model outputs.

BOT is not None. This is intentional — see §6.4 and the class docstring above.
"""


# ---------------------------------------------------------------------------
# Custom exception types
# ---------------------------------------------------------------------------
class ConservationViolation(AssertionError):
    """Raised by assert_conservation when |P| != |D|.

    Invariant 1 (Conservation): Every test example must receive exactly one
    scored prediction. If |P| < |D|, some rows were silently dropped.
    If |P| > |D|, predictions were duplicated.
    """


class ClosedVocabularyViolation(AssertionError):
    """Raised by assert_closed_vocabulary when a label is unreachable or
    two labels collide after normalization.

    Invariant 2 (Closed-Vocabulary): For every label y in the taxonomy,
    normalizer(y) must be a key in the lookup table, and no two labels
    may normalize to the same key.
    """


# ---------------------------------------------------------------------------
# Invariant 1: Conservation
# ---------------------------------------------------------------------------
def assert_conservation(
    scored_predictions: List[Any],
    test_set_size: int,
) -> None:
    """Invariant 1: Conservation.

    Asserts that len(scored_predictions) == test_set_size. Every test example
    must receive exactly one scored prediction (which may be BOT).

    Args:
        scored_predictions: The list of predictions produced by the harness.
        test_set_size: The number of examples in the test set (|D|).

    Raises:
        ConservationViolation: If len(scored_predictions) != test_set_size.

    This is the invariant that would have caught the Dell and Banking77
    incidents: when rows are silently skipped, |P| < |D|.
    """
    n_pred = len(scored_predictions)
    if n_pred != test_set_size:
        raise ConservationViolation(
            f"Conservation violation: |P| = {n_pred} but |D| = {test_set_size}. "
            f"{'%d rows were silently dropped.' % (test_set_size - n_pred) if n_pred < test_set_size else '%d extra predictions.' % (n_pred - test_set_size)}"
        )


# ---------------------------------------------------------------------------
# Invariant 2: Closed-Vocabulary
# ---------------------------------------------------------------------------
def assert_closed_vocabulary(
    labels: List[str],
    normalizer: Callable[[str], str],
    lookup_table: Dict[str, str],
) -> None:
    """Invariant 2: Closed-Vocabulary.

    For every label y in the taxonomy:
      (a) normalizer(y) must be a key in lookup_table (reachability).
      (b) No two distinct labels y1, y2 may satisfy normalizer(y1) == normalizer(y2)
          (no collisions).

    Args:
        labels: The label vocabulary (e.g., BANKING77_LABELS).
        normalizer: The normalization function applied to model outputs.
        lookup_table: The dict mapping normalized strings to label values.

    Raises:
        ClosedVocabularyViolation: On unreachable labels or collisions.

    Example failure (Dell incident): labels=["INSUFFICIENT_INFORMATION"],
    normalizer=norm_underscore_to_space, lookup_table={"INSUFFICIENT_INFORMATION": ...}.
    normalizer("INSUFFICIENT_INFORMATION") = "insufficient information", which is NOT
    a key in the table → ClosedVocabularyViolation raised at startup.
    """
    normalized_to_original: Dict[str, str] = {}
    unreachable: List[str] = []
    collisions: List[tuple] = []

    for label in labels:
        norm_key = normalizer(label)

        # Check (b): collision
        if norm_key in normalized_to_original:
            collisions.append((normalized_to_original[norm_key], label, norm_key))
        else:
            normalized_to_original[norm_key] = label

        # Check (a): reachability
        if norm_key not in lookup_table:
            unreachable.append(label)

    errors = []
    if unreachable:
        errors.append(
            f"Unreachable labels (normalizer(label) not in lookup_table): {unreachable}"
        )
    if collisions:
        errors.append(
            f"Collisions (two labels normalize to same key): "
            + "; ".join(f"'{a}' and '{b}' → '{k}'" for a, b, k in collisions)
        )

    if errors:
        raise ClosedVocabularyViolation(
            "Closed-vocabulary invariant violated:\n" + "\n".join(errors)
        )


# ---------------------------------------------------------------------------
# Invariant 3: Unmatched-Output Accounting
# ---------------------------------------------------------------------------
def route_unmatched_to_bot(
    normalized_output: str,
    lookup_table: Dict[str, str],
    bot_sentinel: Any = None,
) -> Any:
    """Invariant 3: Unmatched-Output Accounting.

    If normalized_output is a key in lookup_table, return the matched value.
    Otherwise, return the ⊥ sentinel (BOT by default, not None).

    Args:
        normalized_output: The normalized model output string.
        lookup_table: The dict mapping normalized strings to label values.
        bot_sentinel: The sentinel to return on mismatch. Defaults to BOT
            (the module-level singleton). Override only in tests.

    Returns:
        The matched label value, or bot_sentinel if no match.

    Design note: The default sentinel is BOT (not None) so that downstream
    code filtering `if x is not None` cannot accidentally drop ⊥ predictions.
    This directly addresses the §6.4 vulnerability.
    """
    sentinel = bot_sentinel if bot_sentinel is not None else BOT
    if normalized_output in lookup_table:
        return lookup_table[normalized_output]
    return sentinel

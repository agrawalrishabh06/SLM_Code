"""
data/taxonomies.py — Canonical label vocabularies for all datasets.

Reviewers should be able to open this file and see exactly the label strings
used in every experiment. These constants are the single source of truth for
the Closed-Vocabulary invariant checks.
"""
from __future__ import annotations
from typing import List

# ---------------------------------------------------------------------------
# Banking77 — 77 intent categories (PolyAI/banking77, HuggingFace order)
# ---------------------------------------------------------------------------
BANKING77_LABELS: List[str] = [
    "activate_my_card",
    "age_limit",
    "apple_pay_or_google_pay",
    "atm_support",
    "automatic_top_up",
    "balance_not_updated_after_bank_transfer",
    "balance_not_updated_after_cheque_or_cash_deposit",
    "beneficiary_not_allowed",
    "cancel_transfer",
    "card_about_to_expire",
    "card_acceptance",
    "card_arrival",
    "card_delivery_estimate",
    "card_linking",
    "card_not_working",
    "card_payment_fee_charged",
    "card_payment_not_recognised",
    "card_payment_wrong_exchange_rate",
    "card_swallowed",
    "cash_withdrawal_charge",
    "cash_withdrawal_not_recognised",
    "change_pin",
    "compromised_card",
    "contactless_not_working",
    "country_support",
    "declined_card_payment",
    "declined_cash_withdrawal",
    "declined_transfer",
    "direct_debit_payment_not_recognised",
    "disposable_card_limits",
    "edit_personal_details",
    "exchange_charge",
    "exchange_rate",
    "exchange_via_app",
    "extra_charge_on_statement",
    "failed_transfer",
    "fiat_currency_support",
    "get_disposable_virtual_card",
    "get_physical_card",
    "getting_spare_card",
    "getting_virtual_card",
    "lost_or_stolen_card",
    "lost_or_stolen_phone",
    "order_physical_card",
    "passcode_forgotten",
    "pending_card_payment",
    "pending_cash_withdrawal",
    "pending_top_up",
    "pending_transfer",
    "pin_blocked",
    "receiving_money",
    "refund_not_showing_up",
    "request_refund",
    "reverted_card_payment?",
    "supported_cards_and_currencies",
    "terminate_account",
    "top_up_by_bank_transfer_charge",
    "top_up_by_card_charge",
    "top_up_by_cash_or_cheque",
    "top_up_failed",
    "top_up_limits",
    "top_up_reverted",
    "topping_up_by_card",
    "transaction_charged_twice",
    "transfer_fee_charged",
    "transfer_into_account",
    "transfer_not_received_by_recipient",
    "transfer_timing",
    "unable_to_verify_identity",
    "verify_my_identity",
    "verify_source_of_funds",
    "verify_top_up",
    "virtual_card_not_working",
    "visa_or_mastercard",
    "why_is_card_charge",
    "wrong_amount_of_cash_received",
    "wrong_exchange_rate_for_cash_withdrawal",
]

assert len(BANKING77_LABELS) == 77, f"Expected 77 Banking77 labels, got {len(BANKING77_LABELS)}"
assert len(set(BANKING77_LABELS)) == 77, "Duplicate labels detected in BANKING77_LABELS"

# ---------------------------------------------------------------------------
# CLINC150 — 150 in-scope intent categories (clinc_oos, plus config)
# Out-of-scope ("oos") is excluded. Labels are in HuggingFace alphabetical order.
# ---------------------------------------------------------------------------
CLINC150_INSCOPE_LABELS: List[str] = [
    # banking domain
    "balance",
    "bill_balance",
    "bill_due",
    "credit_limit",
    "credit_limit_change",
    "credit_score",
    "direct_deposit",
    "freeze_account",
    "interest_rate",
    "new_card",
    "pay_bill",
    "pin_change",
    "report_fraud",
    "routing",
    "transfer",
    # credit_cards domain
    "apr",
    "application_status",
    "card_declined",
    "damaged_card",
    "expiration_date",
    "improve_credit_score",
    "lost_card",
    "redeem_rewards",
    "replacement_card_duration",
    "rewards_balance",
    "spending_history",
    "transactions",
    "w2",
    "pto_balance",
    "pto_request",
    # auto_and_commute domain
    "book_flight",
    "book_hotel",
    "car_rental",
    "gas",
    "gas_type",
    "insurance",
    "insurance_change",
    "jump_start",
    "oil_change_how",
    "oil_change_when",
    "pay_toll",
    "reminder",
    "reminder_update",
    "repeat",
    "roll_odometer",
    # home domain
    "bluetooth_pairing",
    "calendar",
    "calendar_update",
    "cook_time",
    "current_location",
    "definition",
    "distance",
    "do_not_disturb",
    "find_phone",
    "flip_coin",
    "food_last",
    "fun_fact",
    "ingredient_substitution",
    "international_visa",
    "alarm",
    # kitchen_and_dining domain
    "accept_reservations",
    "confirm_reservation",
    "how_busy",
    "make_call",
    "meal_suggestion",
    "meeting_schedule",
    "mpg",
    "next_holiday",
    "no",
    "nutrition_info",
    "order",
    "order_checks",
    "order_status",
    "payday",
    "yes",
    # travel domain
    "carry_on",
    "change_accent",
    "change_ai_name",
    "change_language",
    "change_speed",
    "change_user_name",
    "change_volume",
    "date",
    "directions",
    "exchange_rate",
    "flight_status",
    "freeze",
    "greeting",
    "income",
    "international_fees",
    # utility domain
    "calculator",
    "calories",
    "cancel",
    "cancel_reservation",
    "carry_on_luggage",
    "change_speed_utility",
    "credit_card_not_accepted",
    "currency",
    "damaged_luggage",
    "decode",
    "do_not_disturb_utility",
    "dollar_sign",
    "driver_request",
    "freeze_utility",
    "hearing_problems",
    # work domain
    "account_blocked",
    "age_limit",
    "application_speed",
    "book_appointment",
    "cancel_appointment",
    "change_password",
    "confirm_appointment",
    "contact",
    "delete_account",
    "dunno",
    "food_nearby",
    "goodbye",
    "how_old_are_you",
    "are_you_a_bot",
    "log_in_help",
    # small_talk domain
    "what_are_your_hobbies",
    "what_can_i_ask_you",
    "what_is_your_name",
    "what_song",
    "what_time",
    "where_are_you_from",
    "who_do_you_work_for",
    "who_made_you",
    "meaning_of_life",
    "maybe",
    "min_payment",
    "missed_call",
    "model_type",
    "maybe_utility",
    "next_song",
    # meta domain
    "restaurant_reservation",
    "restaurant_reviews",
    "restaurant_suggestion",
    "roll_dice",
    "rollover_401k",
    "sos",
    "spelling",
    "taxes_1099",
    "taxes_federal",
    "tell_joke",
    "time",
    "timer",
    "timezone",
    "todo_list",
    "todo_list_update",
]

assert len(CLINC150_INSCOPE_LABELS) == 150, (
    f"Expected 150 CLINC150 in-scope labels, got {len(CLINC150_INSCOPE_LABELS)}"
)
assert len(set(CLINC150_INSCOPE_LABELS)) == 150, "Duplicate labels in CLINC150_INSCOPE_LABELS"

# ---------------------------------------------------------------------------
# Dell-like taxonomy — 15 synthetic labels (mirrors Dell incident shape)
# ---------------------------------------------------------------------------
# Labels with underscores (POWER_SUPPLY, GENERAL_RAID, NO_POWER,
# INSUFFICIENT_INFORMATION) are the ones that break under the
# norm_underscore_to_space normalizer, reproducing the Dell incident.
DELL_LIKE_TAXONOMY: List[str] = [
    "BATTERY",
    "BEEP_CODE",
    "BOOT_FAILURE",
    "CPU",
    "DISK",
    "DRIVER_ISSUE",
    "GENERAL_RAID",
    "INSUFFICIENT_INFORMATION",
    "MEMORY",
    "MOTHERBOARD",
    "NETWORK",
    "NO_POWER",
    "OTHER",
    "OVERHEATING",
    "POWER_SUPPLY",
]

assert len(DELL_LIKE_TAXONOMY) == 15, (
    f"Expected 15 Dell-like labels, got {len(DELL_LIKE_TAXONOMY)}"
)
assert len(set(DELL_LIKE_TAXONOMY)) == 15, "Duplicate labels in DELL_LIKE_TAXONOMY"


def get_taxonomy(name: str) -> List[str]:
    """Return the label vocabulary for the given dataset.

    Args:
        name: One of {"banking77", "clinc150", "dell_like"}.

    Returns:
        List of label strings.
    """
    taxonomies = {
        "banking77": BANKING77_LABELS,
        "clinc150": CLINC150_INSCOPE_LABELS,
        "clinc150_inscope": CLINC150_INSCOPE_LABELS,
        "dell_like": DELL_LIKE_TAXONOMY,
    }
    if name not in taxonomies:
        raise ValueError(f"Unknown taxonomy '{name}'. Choose from: {list(taxonomies.keys())}")
    return taxonomies[name]

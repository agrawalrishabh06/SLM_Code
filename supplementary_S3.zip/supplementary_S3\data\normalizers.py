"""
data/normalizers.py — String normalizers audited in the paper.

Each normalizer is a pure function str -> str. These are the exact code paths
the paper claims corrupt scoring when combined with a lookup table built from
un-normalized label strings.

Each function is idempotent: f(f(x)) == f(x) for all x.
"""
from __future__ import annotations

import re


def norm_identity(s: str) -> str:
    """Identity normalizer. Returns the input unchanged.

    Baseline — no normalization applied.
    """
    return s


def norm_strip_lower(s: str) -> str:
    """Strip whitespace and lowercase.

    This is the default normalizer on many lm-evaluation-harness tasks.
    Safe for all Banking77 and CLINC150 labels because they are already
    lowercase with underscores (no whitespace to trip on).
    """
    return s.strip().lower()


def norm_underscore_to_space(s: str) -> str:
    """Strip, lowercase, then replace underscores with spaces.

    THE DELL-INCIDENT NORMALIZER. When the lookup table is built with
    keys like "INSUFFICIENT_INFORMATION" but queries are normalized with
    this function, the key becomes "insufficient information" — which is
    not in the table, so lookup fails silently.

    This is the normalizer documented in §6.1 of the paper.
    """
    return s.strip().lower().replace("_", " ")


def norm_strip_punct(s: str) -> str:
    """Strip whitespace, lowercase, then delete all non-alphanumeric characters.

    HELM-style aggressive canonicalization. Deletes underscores, hyphens,
    question marks, and other punctuation. Note: underscores are DELETED
    (not replaced with spaces), so "reverted_card_payment?" becomes
    "revertedcardpayment" (no spaces). Spaces already present are kept.
    """
    return re.sub(r"[^A-Za-z0-9\s]", "", s.strip().lower())


def norm_banking77_bug(s: str) -> str:
    """Uppercase and strip only.

    THE BANKING77-INCIDENT NORMALIZER. The actual .upper().strip() bug
    documented in §6.2. All lookup table keys were lowercase (the HuggingFace
    label strings are lowercase), so after .upper() every lookup misses.
    The harness then silently skips those rows, inflating accuracy.
    """
    return s.upper().strip()


# ---------------------------------------------------------------------------
# Validation: idempotence and type stability for all normalizers
# ---------------------------------------------------------------------------
_ALL_NORMALIZERS = [
    norm_identity,
    norm_strip_lower,
    norm_underscore_to_space,
    norm_strip_punct,
    norm_banking77_bug,
]

_TEST_STRINGS = [
    "activate_my_card",
    "INSUFFICIENT_INFORMATION",
    "  hello world  ",
    "reverted_card_payment?",
    "",
    "  ",
]

for _fn in _ALL_NORMALIZERS:
    for _s in _TEST_STRINGS:
        _result = _fn(_s)
        assert isinstance(_result, str), (
            f"{_fn.__name__}({_s!r}) returned {type(_result)}, expected str"
        )
        assert _fn(_result) == _result, (
            f"{_fn.__name__} is not idempotent: "
            f"f({_s!r}) = {_result!r}, f(f(...)) = {_fn(_result)!r}"
        )

"""
data/loaders.py — Centralized data loading for Banking77 and CLINC150.

Every experiment reads from here so the loading logic is pinned in one place.
If HuggingFace changes a split size, the assertion gates below will catch it.
"""
from __future__ import annotations

import functools
from typing import Dict, List

EXPECTED_BANKING77_N = 3080
EXPECTED_CLINC150_INSCOPE_N = 4500

_CACHE: Dict[str, List[dict]] = {}


def load_banking77() -> List[Dict]:
    """Load the Banking77 test split from HuggingFace.

    Returns a list of dicts:
        [{"text": str, "label": int, "label_text": str}, ...]

    The test split must have exactly 3,080 examples. If HuggingFace updates
    the split, this assertion will catch the drift before any metric is computed.
    """
    if "banking77" in _CACHE:
        return _CACHE["banking77"]

    from datasets import load_dataset  # type: ignore

    ds = load_dataset("PolyAI/banking77", split="test")
    labels_feature = ds.features["label"]

    records = []
    for row in ds:
        records.append({
            "text": row["text"],
            "label": row["label"],
            "label_text": labels_feature.int2str(row["label"]),
        })

    assert len(records) == EXPECTED_BANKING77_N, (
        f"Banking77 test split has {len(records)} examples; expected {EXPECTED_BANKING77_N}. "
        "The HuggingFace dataset may have changed. The paper's numbers assume 3,080."
    )

    _CACHE["banking77"] = records
    return records


def load_clinc150_inscope() -> List[Dict]:
    """Load the CLINC150 in-scope test split from HuggingFace.

    Loads the 'plus' config and filters out-of-scope examples (label == 42
    in the plus config, but we filter by intent name to be safe).

    Returns a list of dicts:
        [{"text": str, "label": int, "label_text": str}, ...]

    After filtering, the test split must have exactly 4,500 in-scope examples.
    """
    if "clinc150" in _CACHE:
        return _CACHE["clinc150"]

    from datasets import load_dataset  # type: ignore

    ds = load_dataset("clinc_oos", "plus", split="test")
    labels_feature = ds.features["intent"]

    # The out-of-scope label is named "oos" in the plus config.
    # Filter it out to match the paper's in-scope-only setup.
    oos_label_id = labels_feature.str2int("oos")

    records = []
    for row in ds:
        if row["intent"] == oos_label_id:
            continue
        records.append({
            "text": row["text"],
            "label": row["intent"],
            "label_text": labels_feature.int2str(row["intent"]),
        })

    assert len(records) == EXPECTED_CLINC150_INSCOPE_N, (
        f"CLINC150 in-scope test split has {len(records)} examples; "
        f"expected {EXPECTED_CLINC150_INSCOPE_N}. "
        "Verify that the 'plus' config and 'test' split are correct."
    )

    _CACHE["clinc150"] = records
    return records


def get_dataset(name: str, split: str = "test") -> List[Dict]:
    """Dispatcher for dataset loading.

    Args:
        name: One of {"banking77", "clinc150"}.
        split: Currently only "test" is supported.

    Returns:
        List of example dicts.
    """
    if split != "test":
        raise ValueError(f"Only 'test' split is supported; got '{split}'.")
    if name == "banking77":
        return load_banking77()
    elif name in ("clinc150", "clinc150_inscope"):
        return load_clinc150_inscope()
    else:
        raise ValueError(
            f"Unknown dataset '{name}'. Choose from: 'banking77', 'clinc150'."
        )

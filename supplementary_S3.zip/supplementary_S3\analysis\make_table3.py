"""
analysis/make_table3.py — Generate Table 3 of the paper.

Table 3: Summary of the injection study — max Δ and max ⊥ rate per defect.

Reads:  results/table5_full_24cells.csv
Writes: results/table3_summary.csv
        results/table3.tex  (LaTeX booktabs fragment)
"""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "results"

TABLE5_PATH = RESULTS_DIR / "table5_full_24cells.csv"
TABLE3_CSV_PATH = RESULTS_DIR / "table3_summary.csv"
TABLE3_TEX_PATH = RESULTS_DIR / "table3.tex"

DEFECT_INVARIANT_MAP = {
    "D1": "Conservation",
    "D2": "Closed-Vocabulary",
    "D3": "Unmatched-Output",
    "D4": "Unmatched-Output",
}


def generate_table3() -> None:
    """Aggregate table5 into table3 and write CSV + LaTeX."""
    if not TABLE5_PATH.exists():
        raise FileNotFoundError(
            f"{TABLE5_PATH} not found. Run run_injection_matrix.py first."
        )

    defect_stats: dict = defaultdict(lambda: {"max_delta": 0.0, "max_bot_rate": 0.0})

    with open(TABLE5_PATH, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            d = row["defect"]
            delta = float(row["delta_pts"])
            bot_rate = float(row["bot_rate"])
            defect_stats[d]["max_delta"] = max(defect_stats[d]["max_delta"], delta)
            defect_stats[d]["max_bot_rate"] = max(defect_stats[d]["max_bot_rate"], bot_rate)

    summary_rows = [
        {
            "defect": defect,
            "invariant_fired": DEFECT_INVARIANT_MAP.get(defect, "—"),
            "max_delta_pts": stats["max_delta"],
            "max_bot_rate_pct": stats["max_bot_rate"],
        }
        for defect, stats in sorted(defect_stats.items())
    ]

    # Write CSV
    with open(TABLE3_CSV_PATH, "w", newline="") as f:
        writer = csv.DictWriter(
            f, fieldnames=["defect", "invariant_fired", "max_delta_pts", "max_bot_rate_pct"]
        )
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"Written: {TABLE3_CSV_PATH}")

    # Write LaTeX booktabs fragment
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Summary of defect injection study (Table 3). Max accuracy inflation $\Delta$ and",
        r"         max $\bot$ rate across all 3 models $\times$ 2 datasets.}",
        r"\label{tab:injection-summary}",
        r"\begin{tabular}{llrr}",
        r"\toprule",
        r"Defect & Invariant Triggered & Max $\Delta$ (pp) & Max $\bot$ Rate (\%) \\",
        r"\midrule",
    ]
    for row in summary_rows:
        lines.append(
            f"  {row['defect']} & {row['invariant_fired']} & "
            f"{row['max_delta_pts']:.1f} & {row['max_bot_rate_pct']:.1f} \\\\"
        )
    lines += [
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table}",
    ]

    with open(TABLE3_TEX_PATH, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Written: {TABLE3_TEX_PATH}")


if __name__ == "__main__":
    generate_table3()
